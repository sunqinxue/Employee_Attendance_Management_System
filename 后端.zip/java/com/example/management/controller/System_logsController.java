package com.example.factory.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.factory.dto.PageDto;
import com.example.factory.service.ISystem_logsService;

/**
 * @Description: 系统日志管理专属Controller
 * 
 * @author: 孙勤学
 * 
 * 
 * @date: 2025/9/4
 */
@CrossOrigin("*") // 允许跨域访问
@RestController
@RequestMapping("/newSystem_logs")
public class System_logsController {

	@Autowired
	ISystem_logsService system_logsService;

	/**
	 * [查询系统日志的方法（单表）]
	 * 
	 * @param: keywords
	 *             用于查询的关键字
	 * @param: pageNum
	 *             当前页码
	 * @param: maxPageNum
	 *             每页显示的记录数量
	 * @return: PageDto 数据传输对象
	 */
	@RequestMapping("listSystem_logs")
	public PageDto listSystem_logs(String keywords, String pageNum, String maxPageNum) {
		System.out.println("keywords=" + keywords + " pageNum=" + pageNum + " maxPageNum=" + maxPageNum);
		return system_logsService.listSystem_logs(keywords, Integer.parseInt(pageNum), Integer.parseInt(maxPageNum));
	}

	/**
	 * [查询系统日志的方法（多表）]
	 * 
	 * @param: keywords
	 *             用于查询的关键字
	 * @param: pageNum
	 *             当前页码
	 * @param: maxPageNum
	 *             每页显示的记录数量
	 * @return: PageDto 数据传输对象
	 */
	@RequestMapping("listSystem_logs02")
	public PageDto listSystem_logs02(String keywords, String pageNum, String maxPageNum) {
		System.out.println("keywords=" + keywords + " pageNum=" + pageNum + " maxPageNum=" + maxPageNum);
		return system_logsService.listSystem_logs02(keywords, Integer.parseInt(pageNum), Integer.parseInt(maxPageNum));
	}

	/**
	 * [添加系统日志的方法]
	 * 
	 * @param: system_logs
	 *             包含系统日志信息的Map集合
	 * @return: 字符串 "1"==添加成功 "0"==添加失败
	 */
	@RequestMapping(value = "addSystem_logs")
	public String addSystem_logs(@RequestParam Map<String, Object> system_logs) {
		int result = system_logsService.addSystem_logs(system_logs);
		if (result == 1) {
			return "1";
		}
		return "0";
	}

	/**
	 * [更新系统日志信息的方法]
	 * 
	 * @param: system_logs
	 *             包含更新系统日志信息的Map集合
	 * @return: 字符串 "1"==更新成功 "0"==更新失败
	 */
	@RequestMapping("updateSystem_logs")
	public String updateSystem_logs(@RequestParam Map<String, Object> system_logs) {
		int i = system_logsService.updateSystem_logsById(system_logs);
		if (i == 1) {
			return "1";
		}
		return "0";
	}

	/**
	 * [根据日志ID删除系统日志的方法 可以批量删除]
	 * 
	 * @param: log_id
	 *             包含日志ID的字符串
	 * @return: 字符串 "1"==删除成功 "0"==删除失败
	 */
	@RequestMapping("deleteSystem_logs")
	public String deleteSystem_logsById(@RequestParam String log_id) {
		System.out.println("System_logsController id=" + log_id);
		int result = system_logsService.deleteSystem_logsByIds(log_id);
		if (result == 1) {
			return "1";
		}
		return "0";
	}
}

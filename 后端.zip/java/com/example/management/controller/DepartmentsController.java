package com.example.factory.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.factory.dto.PageDto;
import com.example.factory.service.IDepartmentsService;

/**
 * @Description: 部门管理专属Controller
 * 
 * @author: 孙勤学
 * 
 * @date: 2025/9/4
 */
@CrossOrigin("*") // 允许跨域访问
@RestController
@RequestMapping("/departments")
public class DepartmentsController {

	@Autowired
	IDepartmentsService departmentsService;

	/**
	 * [查询部门的方法（单表）]
	 * 
	 * @param: keywords
	 *             用于查询的关键字
	 * @param: pageNum
	 *             当前页码
	 * @param: maxPageNum
	 *             每页显示的记录数量
	 * @return: PageDto 数据传输对象
	 */
	@RequestMapping("listDepartments")
	public PageDto listDepartments(String keywords, String pageNum, String maxPageNum) {
		System.out.println("keywords=" + keywords + " pageNum=" + pageNum + " maxPageNum=" + maxPageNum);
		return departmentsService.listDepartments(keywords, Integer.parseInt(pageNum), Integer.parseInt(maxPageNum));
	}

	/**
	 * [查询部门的方法（多表）]
	 * 
	 * @param: keywords
	 *             用于查询的关键字
	 * @param: pageNum
	 *             当前页码
	 * @param: maxPageNum
	 *             每页显示的记录数量
	 * @return: PageDto 数据传输对象
	 */
	@RequestMapping("listDepartments02")
	public PageDto listDepartments02(String keywords, String pageNum, String maxPageNum) {
		System.out.println("keywords=" + keywords + " pageNum=" + pageNum + " maxPageNum=" + maxPageNum);
		return departmentsService.listDepartments02(keywords, Integer.parseInt(pageNum), Integer.parseInt(maxPageNum));
	}

	/**
	 * [添加部门的方法]
	 * 
	 * @param: departments
	 *             包含部门信息的Map集合
	 * @return: 字符串 "1"==添加成功 "0"==添加失败
	 */
	@RequestMapping(value = "addDepartments")
	public String addDepartments(@RequestParam Map<String, Object> departments) {
		int result = departmentsService.addDepartments(departments);
		if (result == 1) {
			return "1";
		}
		return "0";
	}

	/**
	 * [更新部门信息的方法]
	 * 
	 * @param: departments
	 *             包含更新部门信息的Map集合
	 * @return: 字符串 "1"==更新成功 "0"==更新失败
	 */
	@RequestMapping("updateDepartments")
	public String updateDepartments(@RequestParam Map<String, Object> departments) {
		int i = departmentsService.updateDepartmentsById(departments);
		if (i == 1) {
			return "1";
		}
		return "0";
	}

	/**
	 * [根据部门号删除部门的方法 可以批量删除]
	 * 
	 * @param: department_id
	 *             包含部门号的字符串
	 * @return: 字符串 "1"==删除成功 "0"==删除失败
	 */
	@RequestMapping("deleteDepartments")
	public String deleteDepartmentsById(@RequestParam String department_id) {
		System.out.println("DepartmentsController id=" + department_id);
		int result = departmentsService.deleteDepartmentsByIds(department_id);
		if (result == 1) {
			return "1";
		}
		return "0";
	}
}

package com.example.factory.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.factory.po.User;
import com.example.factory.service.IFactoryService;
import com.example.factory.service.IUserService;

//给工厂表 加入工厂名称 唯一性约束 人为造成异常 测试 事务的回滚
// ALTER TABLE factory ADD UNIQUE(factoryName);
// ALTER TABLE factory  DROP INDEX factoryName;

/**
 * @Description: 事务测试Controller
 * 
 * @author: 
 * 
 * @date: 
 */
@CrossOrigin("*") // 允许跨域访问
@RestController
@RequestMapping("/trans")
public class TransactionController {

	@Autowired
	IUserService userService;

	@Autowired
	IFactoryService factoryService;

	// 添加 事务注解
	@Transactional
	@RequestMapping(value = "addUserFactory")
	public String addUsertFactory(@RequestParam Map<String, Object> user, @RequestParam Map<String, Object> factory) {
		// 执行数据库操作
		// 如果这里的代码抛出异常，事务将被回滚

		System.out.println("addUserFactory");

		String user_name = (String) user.get("user_name");
		String user_password = (String) user.get("user_password");
		String real_name = (String) user.get("real_name");
		String role_id = (String) user.get("role_id");

		User u = new User();
		// user_name=abc&user_password=123&real_name=ZZ&role_id=2
		u.setUser_name(user_name);
		u.setUser_password(user_password);
		u.setReal_name(real_name);
		u.setRole_id(role_id);

		int result = userService.addUser2(u);
		System.out.println("0000---result=" + result);
		int key = u.getId();
		System.out.println("0000---key=" + key);

		factory.put("user_id", "" + key);

		// 给工厂表 加入工厂名称 唯一性约束 人为造成异常 测试 事务的回滚
		// ALTER TABLE factory ADD UNIQUE(factoryName);

		int result2 = factoryService.addFactory(factory);
		System.out.println("0000---result2=" + result2);

//		if (result == 1) {
//			return "1";
//		}
		return "00000";
	}
}
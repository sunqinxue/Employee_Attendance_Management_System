package com.example.factory.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.factory.dto.PageDto;
import com.example.factory.service.IClock_recordsService;

/**
 * @Description: 打卡记录管理专属Controller
 * 
 * @author: 孙勤学
 * 
 * @date: 2025/9/2
 */
@CrossOrigin("*") // 允许跨域访问
@RestController
@RequestMapping("/newClock_records")
public class Clock_recordsController {

	@Autowired
	IClock_recordsService clock_recordsService;

	/**
	 * [查询打卡记录的方法]
	 * 
	 * @param: keywords
	 *             用于查询的关键字
	 * @param: pageNum
	 *             当前页码
	 * @param: maxPageNum
	 *             每页显示的记录数量
	 * @return: PageDto 数据传输对象
	 */
	@RequestMapping("listClock_records") // @RequestParam method =
	// RequestMethod.POST
	public PageDto listClock_records(String keywords, String pageNum, String maxPageNum) {
		System.out.println("keywords=" + keywords + " pageNum=" + pageNum + " maxPageNum=" + maxPageNum);
		return clock_recordsService.listClock_records(keywords, Integer.parseInt(pageNum),
				Integer.parseInt(maxPageNum));
	}

	/**
	 * [添加打卡记录的方法]
	 * 
	 * @param: clock_records
	 *             包含打卡记录信息的Map集合
	 * @return: 字符串 "1"==添加成功 "0"==添加失败 method = RequestMethod.POST
	 */
	@RequestMapping(value = "addClock_records")
	public String addClock_records(@RequestParam Map<String, Object> clock_records) {
		int result = clock_recordsService.addClock_records(clock_records);
		if (result == 1) {
			return "1";
		}
		return "0";
	}

	/**
	 * [更新打卡记录信息的方法]
	 * 
	 * @param: clock_records
	 *             包含更新打卡记录信息的Map集合
	 * @return: 字符串 "1"==添加成功 "0"==添加失败
	 */
	// @RequestMapping(value = "updateClock_records", method =
	// RequestMethod.POST) // GET
	// POST
	@RequestMapping("updateClock_records")
	public String updateClock_records(@RequestParam Map<String, Object> clock_records) {
		int i = clock_recordsService.updateClock_recordsById(clock_records);
		if (i == 1) {
			return "1";
		}
		return "0";
	}

	/**
	 * [根据打卡记录号删除打卡记录的方法 可以批量删除]
	 * 
	 * @param: record_id
	 *             包含打卡记录号的字符串
	 * @return: 字符串 "1"==添加成功 "0"==添加失败
	 */
	@RequestMapping("deleteClock_records")
	public String deleteClock_recordsById(@RequestParam String record_id) {
		System.out.println("Clock_recordsController id=" + record_id);
		int result = clock_recordsService.deleteClock_recordsByIds(record_id);
		if (result == 1) {
			return "1";
		}
		return "0";
	}
}
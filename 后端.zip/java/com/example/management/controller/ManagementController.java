package com.example.factory.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.factory.dto.PageDto;
import com.example.factory.service.IFactoryService;

/**
 * @Description: 工厂管理专属Controller
 * 
 * @author:
 * 
 * @date: 
 */
@CrossOrigin("*") // 允许跨域访问
@RestController
@RequestMapping("/newFactory")
public class FactoryController {

	@Autowired
	IFactoryService factoryService;

	/**
	 * [查询工厂的方法]
	 * 
	 * @param: keywords   用于查询的关键字
	 * @param: pageNum    当前页码
	 * @param: maxPageNum 每页显示的记录数量
	 * @return: PageDto 数据传输对象
	 */
	@RequestMapping("listFactory") // @RequestParam method = RequestMethod.POST
	public PageDto listFactory(String keywords, String pageNum, String maxPageNum) {
		System.out.println("keywords=" + keywords + " pageNum=" + pageNum + " maxPageNum=" + maxPageNum);
		return factoryService.listFactory(keywords, Integer.parseInt(pageNum), Integer.parseInt(maxPageNum));
	}

	/**
	 * [按user_id查询工厂的方法]
	 * 
	 * @param: user_id 用于查询的关键字
	 * @return: PageDto 数据传输对象
	 */
	@RequestMapping("listFactoryByUserid") // @RequestParam method = RequestMethod.POST
	public PageDto listFactoryByUserid(String user_id) {
		System.out.println("user_id=" + user_id);
		return factoryService.listFactoryByUserid(user_id);// Integer.parseInt(user_id)
	}

	/**
	 * [添加工厂的方法]
	 * 
	 * @param: dept 包含工厂信息的Map集合
	 * @return: 字符串 "1"==添加成功 "0"==添加失败 method = RequestMethod.POST
	 */
	@RequestMapping(value = "addFactory")
	public String addFactory(@RequestParam Map<String, Object> factory) {
		int result = factoryService.addFactory(factory);
		if (result == 1) {
			return "1";
		}
		return "0";
	}

	/**
	 * [更新工厂信息的方法]
	 * 
	 * @param: dept 包含更工厂工信息的Map集合
	 * @return: 字符串 "1"==添加成功 "0"==添加失败
	 */
	// @RequestMapping(value = "updateDept", method = RequestMethod.POST) // GET
	// POST
	@RequestMapping("updateFactory")
	public String updateFactory(@RequestParam Map<String, Object> factory) {
		int i = factoryService.updateFactoryById(factory);
		if (i == 1) {
			return "1";
		}
		return "0";
	}

	/**
	 * [根据员工号删除工厂的方法 可以批量删除]
	 * 
	 * @param: deptno 包含员工号的字符串
	 * @return: 字符串 "1"==添加成功 "0"==添加失败
	 */
	@RequestMapping("deleteFactory")
	public String deleteFactoryById(@RequestParam String id) {
		System.out.println("FactoryController factoryno=" + id);
		int result = factoryService.deleteFactoryByIds(id);
		if (result == 1) {
			return "1";
		}
		return "0";
	}
}
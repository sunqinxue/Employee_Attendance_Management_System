package com.example.factory.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.factory.dto.PageDto;
import com.example.factory.service.IShiftsService;

/**
 * @Description: 班次管理专属Controller
 * 
 * @author: 孙勤学
 * 
 * @date: 2025/9/4
 */
@CrossOrigin("*") // 允许跨域访问
@RestController
@RequestMapping("/newShifts")
public class ShiftsController {

	@Autowired
	IShiftsService shiftsService;

	/**
	 * [查询班次的方法（单表）]
	 * 
	 * @param: keywords
	 *             用于查询的关键字
	 * @param: pageNum
	 *             当前页码
	 * @param: maxPageNum
	 *             每页显示的记录数量
	 * @return: PageDto 数据传输对象
	 */
	@RequestMapping("listShifts") // @RequestParam method =
									// RequestMethod.POST
	public PageDto listShifts(String keywords, String pageNum, String maxPageNum) {
		System.out.println("keywords=" + keywords + " pageNum=" + pageNum + " maxPageNum=" + maxPageNum);
		return shiftsService.listShifts(keywords, Integer.parseInt(pageNum), Integer.parseInt(maxPageNum));
	}

	/**
	 * [查询班次的方法（多表）]
	 * 
	 * @param: keywords
	 *             用于查询的关键字
	 * @param: pageNum
	 *             当前页码
	 * @param: maxPageNum
	 *             每页显示的记录数量
	 * @return: PageDto 数据传输对象
	 */
	@RequestMapping("listShifts02") // @RequestParam method =
									// RequestMethod.POST
	public PageDto listShifts02(String keywords, String pageNum, String maxPageNum) {
		System.out.println("keywords=" + keywords + " pageNum=" + pageNum + " maxPageNum=" + maxPageNum);
		return shiftsService.listShifts02(keywords, Integer.parseInt(pageNum), Integer.parseInt(maxPageNum));
	}

	/**
	 * [添加班次的方法]
	 * 
	 * @param: shifts
	 *             包含班次信息的Map集合
	 * @return: 字符串 "1"==添加成功 "0"==添加失败 method = RequestMethod.POST
	 */
	@RequestMapping(value = "addShifts")
	public String addShifts(@RequestParam Map<String, Object> shifts) {
		int result = shiftsService.addShifts(shifts);
		if (result == 1) {
			return "1";
		}
		return "0";
	}

	/**
	 * [更新班次信息的方法]
	 * 
	 * @param: shifts
	 *             包含更新班次信息的Map集合
	 * @return: 字符串 "1"==添加成功 "0"==添加失败
	 */
	// @RequestMapping(value = "updateShifts", method = RequestMethod.POST) //
	// GET
	// POST
	@RequestMapping("updateShifts")
	public String updateShifts(@RequestParam Map<String, Object> shifts) {
		int i = shiftsService.updateShiftsById(shifts);
		if (i == 1) {
			return "1";
		}
		return "0";
	}

	/**
	 * [根据班次号删除班次的方法 可以批量删除]
	 * 
	 * @param: shift_id
	 *             包含班次号的字符串
	 * @return: 字符串 "1"==添加成功 "0"==添加失败
	 */
	@RequestMapping("deleteShifts")
	public String deleteShiftsById(@RequestParam String shift_id) {
		System.out.println("ShiftsController id=" + shift_id);
		int result = shiftsService.deleteShiftsByIds(shift_id);
		if (result == 1) {
			return "1";
		}
		return "0";
	}
}
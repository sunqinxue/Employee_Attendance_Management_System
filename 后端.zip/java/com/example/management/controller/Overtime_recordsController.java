package com.example.factory.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.factory.dto.PageDto;
import com.example.factory.service.IOvertime_recordsService;

/**
 * @Description: 加班记录管理专属Controller
 * 
 * @author: 徐天鹏
 * 
 * @date: 2025/9/2
 */
@CrossOrigin("*") // 允许跨域访问
@RestController
@RequestMapping("/newOvertime_records")
public class Overtime_recordsController {

	@Autowired
	IOvertime_recordsService overtime_recordsService;

	/**
	 * [查询加班记录的方法]
	 * 
	 * @param: keywords
	 *             用于查询的关键字
	 * @param: pageNum
	 *             当前页码（默认1）
	 * @param: maxPageNum
	 *             每页显示的记录数量（默认10）
	 * @return: PageDto 数据传输对象
	 */
	// 给pageNum和maxPageNum添加@RequestParam，设置默认值，避免空字符串
	@RequestMapping("listOvertime_records")
	public PageDto listOvertime_records(String keywords, @RequestParam(defaultValue = "1") String pageNum, // 默认页码1
			@RequestParam(defaultValue = "10") String maxPageNum) { // 默认每页10条
		System.out.println("keywords=" + keywords + " pageNum=" + pageNum + " maxPageNum=" + maxPageNum);
		// 此时pageNum和maxPageNum不会为空，转换安全
		return overtime_recordsService.listOvertime_records(keywords, Integer.parseInt(pageNum),
				Integer.parseInt(maxPageNum));
	}

	/**
	 * [添加加班记录的方法]
	 * 
	 * @param: overtime_records
	 *             包含加班记录信息的Map集合
	 * @return: 字符串 "1"==添加成功 "0"==添加失败
	 */
	@RequestMapping(value = "addOvertime_records")
	public String addOvertime_records(@RequestParam Map<String, Object> overtime_records) {
		int result = overtime_recordsService.addOvertime_records(overtime_records);
		if (result == 1) {
			return "1";
		}
		return "0";
	}

	/**
	 * [更新加班记录信息的方法]
	 * 
	 * @param: overtime_records
	 *             包含更新加班记录信息的Map集合
	 * @return: 字符串 "1"==添加成功 "0"==添加失败
	 */
	@RequestMapping("updateOvertime_records")
	public String updateOvertime_records(@RequestParam Map<String, Object> overtime_records) {
		int i = overtime_recordsService.updateOvertime_recordsById(overtime_records);
		if (i == 1) {
			return "1";
		}
		return "0";
	}

	/**
	 * [根据加班记录号删除加班记录的方法 可以批量删除]
	 * 
	 * @param: overtime_id
	 *             包含加班记录号的字符串
	 * @return: 字符串 "1"==添加成功 "0"==添加失败
	 */
	@RequestMapping("deleteOvertime_records")
	public String deleteOvertime_recordsById(@RequestParam String overtime_id) {
		System.out.println("Overtime_recordsController id=" + overtime_id);
		int result = overtime_recordsService.deleteOvertime_recordsByIds(overtime_id);
		if (result == 1) {
			return "1";
		}
		return "0";
	}
}

package com.example.factory.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.factory.dto.PageDto;
import com.example.factory.service.ILeave_typesService;

/**
 * @Description: 请假类型管理专属Controller
 * 
 * @author: 孙勤学
 * 
 * @date: 2025/9/4
 */
@CrossOrigin("*") // 允许跨域访问
@RestController
@RequestMapping("/newLeave_types")
public class Leave_typesController {

	@Autowired
	ILeave_typesService leave_typesService;

	/**
	 * [查询请假类型的方法]
	 * 
	 * @param: keywords
	 *             用于查询的关键字
	 * @param: pageNum
	 *             当前页码
	 * @param: maxPageNum
	 *             每页显示的记录数量
	 * @return: PageDto 数据传输对象
	 */
	@RequestMapping("listLeave_types") // @RequestParam method =
	// RequestMethod.POST
	public PageDto listLeave_types(String keywords, String pageNum, String maxPageNum) {
		System.out.println("keywords=" + keywords + " pageNum=" + pageNum + " maxPageNum=" + maxPageNum);
		return leave_typesService.listLeave_types(keywords, Integer.parseInt(pageNum), Integer.parseInt(maxPageNum));
	}

	/**
	 * [添加请假类型的方法]
	 * 
	 * @param: leave_types
	 *             包含请假类型信息的Map集合
	 * @return: 字符串 "1"==添加成功 "0"==添加失败 method = RequestMethod.POST
	 */
	@RequestMapping(value = "addLeave_types")
	public String addLeave_types(@RequestParam Map<String, Object> leave_types) {
		int result = leave_typesService.addLeave_types(leave_types);
		if (result == 1) {
			return "1";
		}
		return "0";
	}

	/**
	 * [更新请假类型信息的方法]
	 * 
	 * @param: leave_types
	 *             包含更新请假类型信息的Map集合
	 * @return: 字符串 "1"==添加成功 "0"==添加失败
	 */
	// @RequestMapping(value = "updateLeave_types", method = RequestMethod.POST)
	// // GET
	// POST
	@RequestMapping("updateLeave_types")
	public String updateLeave_types(@RequestParam Map<String, Object> leave_types) {
		int i = leave_typesService.updateLeave_typesById(leave_types);
		if (i == 1) {
			return "1";
		}
		return "0";
	}

	/**
	 * [根据请假类型号删除请假类型的方法 可以批量删除]
	 * 
	 * @param: type_id
	 *             包含请假类型号的字符串
	 * @return: 字符串 "1"==添加成功 "0"==添加失败
	 */
	@RequestMapping("deleteLeave_types")
	public String deleteLeave_typesById(@RequestParam String type_id) {
		System.out.println("Leave_typesController id=" + type_id);
		int result = leave_typesService.deleteLeave_typesByIds(type_id);
		if (result == 1) {
			return "1";
		}
		return "0";
	}
}
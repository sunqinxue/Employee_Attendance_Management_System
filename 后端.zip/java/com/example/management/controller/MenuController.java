package com.example.factory.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.factory.po.Menu;
import com.example.factory.po.User;
import com.example.factory.service.IMenuService;

/**
 * @Description: 菜单管理专属Controller
 * 
 * @author: 
 * 
 * @date: 
 */
@CrossOrigin("*") // 允许跨域访问
@RestController
@RequestMapping("/newMenu")
public class MenuController {

	@Autowired
	IMenuService menuService;

	@RequestMapping("listMenu")
	public java.util.List<Menu> list(int roleId) {
		return menuService.listMenu(roleId);
	}

	/**
	 * [通过用户名和密码查找指定的用户对象==用户登录]
	 * 
	 * @param: username 用户名, password 密码
	 * @return: 指定的用户对象
	 */
	@RequestMapping(value = "login", method = RequestMethod.GET) // @RequestParam @RequestParam
	public User getUserBean(String username, String password, HttpSession session) {
		User user = menuService.login(username, password);
		if (user != null) {
			session.setAttribute("login_user", user);
			return user;
		} else {
			return null;
		}
	}
}

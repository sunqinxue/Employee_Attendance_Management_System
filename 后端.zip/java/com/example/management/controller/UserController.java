package com.example.factory.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.factory.dto.PageDto;
import com.example.factory.po.User;
import com.example.factory.service.IUserService;

/**
 * @Description: 用户管理专属Controller
 * 
 * @author:
 * 
 * @date: 
 */
@CrossOrigin("*") // 允许跨域访问
@RestController
@RequestMapping("/newUser")
public class UserController {

	@Autowired
	IUserService userService;

	/**
	 * [查询用户的方法]
	 * 
	 * @param: keywords   用于查询的关键字
	 * @param: pageNum    当前页码
	 * @param: maxPageNum 每页显示的记录数量
	 * @return: PageDto 数据传输对象
	 */
	@RequestMapping("listUser") // @RequestParam method = RequestMethod.POST
	public PageDto listUser(String keywords, String pageNum, String maxPageNum) {
		System.out.println("keywords=" + keywords + " pageNum=" + pageNum + " maxPageNum=" + maxPageNum);
		return userService.listUser(keywords, Integer.parseInt(pageNum), Integer.parseInt(maxPageNum));
	}

	/**
	 * [添加用户的方法]
	 * 
	 * @param: user 包含部门信息的Map集合
	 * @return: 字符串 "1"==添加成功 "0"==添加失败 method = RequestMethod.POST
	 */
	@RequestMapping(value = "addUser")
	public String addUser(@RequestParam Map<String, Object> user) {
		int result = userService.addUser(user);
		if (result == 1) {
			return "1";
		}
		return "0";
	}

	/**
	 * [添加用户的方法 返回主键]
	 * 
	 * @param: user 包含用户信息的Map集合
	 * @return: 字符串 "1"==添加成功 "0"==添加失败 method = RequestMethod.POST
	 */
	@RequestMapping(value = "addUser2") // Map<String, Object> dept
	public String addUser2(User user) { // 好使的
		// public String addUser2(Map<String, Object> user) { //不行
		System.out.println("addUser2");
		int result = userService.addUser2(user);
		System.out.println("result=" + result);
		int key = user.getId();
		System.out.println("key=" + key);
		if (result == 0) {
			return "0";
		}
		return "" + key; // result; key
	}

	/**
	 * [更新用户信息的方法]
	 * 
	 * @param: user 包含更新部门信息的Map集合
	 * @return: 字符串 "1"==添加成功 "0"==添加失败
	 */
	// @RequestMapping(value = "updateDept", method = RequestMethod.POST) // GET
	// POST
	@RequestMapping("updateUser")
	public String updateUser(@RequestParam Map<String, Object> user) {
		int i = userService.updateUserById(user);
		if (i == 1) {
			return "1";
		}
		return "0";
	}

	/**
	 * [根据用户号删除部门的方法 可以批量删除]
	 * 
	 * @param: id 包含用户号的字符串
	 * @return: 字符串 "1"==添加成功 "0"==添加失败
	 */
	@RequestMapping("deleteUser")
	public String deleteUserById(@RequestParam String id) {
		System.out.println("UserController id=" + id);
		int result = userService.deleteUserByIds(id);
		if (result == 1) {
			return "1";
		}
		return "0";
	}
}
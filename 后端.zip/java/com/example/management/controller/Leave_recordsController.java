package com.example.factory.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.factory.dto.PageDto;
import com.example.factory.service.ILeave_recordsService;

/**
 * @Description: 请假记录管理专属Controller
 * 
 * @author: 徐天鹏
 * 
 * @date: 2025/9/4
 */
@CrossOrigin("*") // 允许跨域访问
@RestController
@RequestMapping("/newLeave_records")
public class Leave_recordsController {

	@Autowired
	ILeave_recordsService leave_recordsService;

	/**
	 * [查询请假记录的方法（单表）]
	 * 
	 * @param: keywords
	 *             用于查询的关键字
	 * @param: pageNum
	 *             当前页码
	 * @param: maxPageNum
	 *             每页显示的记录数量
	 * @return: PageDto 数据传输对象
	 */
	@RequestMapping("listLeave_records") // @RequestParam method =
	// RequestMethod.POST
	public PageDto listLeave_records(String keywords, String pageNum, String maxPageNum) {
		System.out.println("keywords=" + keywords + " pageNum=" + pageNum + " maxPageNum=" + maxPageNum);
		return leave_recordsService.listLeave_records(keywords, Integer.parseInt(pageNum),
				Integer.parseInt(maxPageNum));
	}

	/**
	 * [查询请假记录的方法（多表）]
	 * 
	 * @param: keywords
	 *             用于查询的关键字
	 * @param: pageNum
	 *             当前页码
	 * @param: maxPageNum
	 *             每页显示的记录数量
	 * @return: PageDto 数据传输对象
	 */
	@RequestMapping("listLeave_records02") // @RequestParam method =
	// RequestMethod.POST
	public PageDto listLeave_records02(String keywords, String pageNum, String maxPageNum) {
		System.out.println("keywords=" + keywords + " pageNum=" + pageNum + " maxPageNum=" + maxPageNum);
		return leave_recordsService.listLeave_records02(keywords, Integer.parseInt(pageNum),
				Integer.parseInt(maxPageNum));
	}

	/**
	 * [添加请假记录的方法]
	 * 
	 * @param: leave_records
	 *             包含请假记录信息的Map集合
	 * @return: 字符串 "1"==添加成功 "0"==添加失败 method = RequestMethod.POST
	 */
	@RequestMapping(value = "addLeave_records")
	public String addLeave_records(@RequestParam Map<String, Object> leave_records) {
		int result = leave_recordsService.addLeave_records(leave_records);
		if (result == 1) {
			return "1";
		}
		return "0";
	}

	/**
	 * [更新请假记录信息的方法]
	 * 
	 * @param: leave_records
	 *             包含更新请假记录信息的Map集合
	 * @return: 字符串 "1"==添加成功 "0"==添加失败
	 */
	// @RequestMapping(value = "updateLeave_records", method =
	// RequestMethod.POST) //
	// GET
	// POST
	@RequestMapping("updateLeave_records")
	public String updateLeave_records(@RequestParam Map<String, Object> leave_records) {
		int i = leave_recordsService.updateLeave_recordsById(leave_records);
		if (i == 1) {
			return "1";
		}
		return "0";
	}

	/**
	 * [根据请假记录号删除请假记录的方法 可以批量删除]
	 * 
	 * @param: leave_id
	 *             包含请假记录号的字符串
	 * @return: 字符串 "1"==添加成功 "0"==添加失败
	 */
	@RequestMapping("deleteLeave_records")
	public String deleteLeave_recordsById(@RequestParam String leave_id) {
		System.out.println("Leave_recordsController id=" + leave_id);
		int result = leave_recordsService.deleteLeave_recordsByIds(leave_id);
		if (result == 1) {
			return "1";
		}
		return "0";
	}
}
package com.example.factory.service;

import java.util.Map;

import com.example.factory.dto.PageDto;

/**
 * @Description: 班次表Service接口
 * 
 * @author: 孙勤学
 * @date: 2025/9/4
 * 
 */
public interface IShiftsService {

	/**
	 * @Description: 分页查询班次表（单表）
	 * @param: keywords
	 *             查询条件关键字
	 * @param: pageNum
	 *             当前页数
	 * @param: maxPageNum
	 *             每页最多显示的记录数
	 * @return: dto对象
	 * @exception: 无
	 */
	public PageDto listShifts(String keywords, int pageNum, int maxPageNum);

	/**
	 * @Description: 分页查询班次表（多表）
	 * @param: keywords
	 *             查询条件关键字
	 * @param: pageNum
	 *             当前页数
	 * @param: maxPageNum
	 *             每页最多显示的记录数
	 * @return: dto对象
	 * @exception: 无
	 */
	public PageDto listShifts02(String keywords, int pageNum, int maxPageNum);

	/**
	 * @Description: 班次表添加
	 * @param: shifts
	 *             包含班次表信息的Map对象
	 * @return: 整数 1==添加成功 0==添加失败
	 * @exception: 无
	 */
	int addShifts(Map<String, Object> shifts);

	/**
	 * @Description: 班次表更新
	 * @param: shifts
	 *             包含班次表，信息的Map对象
	 * @return: 整数 1==添加成功 0==添加失败
	 * @exception: 无
	 */
	public int updateShiftsById(Map<String, Object> shifts);

	/**
	 * @Description: 班次表删除
	 * @param: shift_id
	 *             包含班次表编号信的字符串对象
	 * @return: 整数 1==删除成功 0==删除失败
	 * @exception: 无
	 */
	public int deleteShiftsByIds(String shift_id);
}

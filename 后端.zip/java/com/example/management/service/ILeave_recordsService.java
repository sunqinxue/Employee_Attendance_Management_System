package com.example.factory.service;

import java.util.Map;

import com.example.factory.dto.PageDto;

/**
 * @Description: 请假记录表Service接口
 * 
 * @author: 徐天鹏
 * @date: 2025/9/4
 * 
 */
public interface ILeave_recordsService {

	/**
	 * @Description: 分页查询请假记录表（单表）
	 * @param: keywords
	 *             查询条件关键字
	 * @param: pageNum
	 *             当前页数
	 * @param: maxPageNum
	 *             每页最多显示的记录数
	 * @return: dto对象
	 * @exception: 无
	 */
	public PageDto listLeave_records(String keywords, int pageNum, int maxPageNum);

	/**
	 * @Description: 分页查询请假记录表（多表）
	 * @param: keywords
	 *             查询条件关键字
	 * @param: pageNum
	 *             当前页数
	 * @param: maxPageNum
	 *             每页最多显示的记录数
	 * @return: dto对象
	 * @exception: 无
	 */
	public PageDto listLeave_records02(String keywords, int pageNum, int maxPageNum);

	/**
	 * @Description: 请假记录表添加
	 * @param: leave_records
	 *             包含请假记录表信息的Map对象
	 * @return: 整数 1==添加成功 0==添加失败
	 * @exception: 无
	 */
	int addLeave_records(Map<String, Object> leave_records);

	/**
	 * @Description: 请假记录表更新
	 * @param: leave_records
	 *             包含请假记录表，信息的Map对象
	 * @return: 整数 1==添加成功 0==添加失败
	 * @exception: 无
	 */
	public int updateLeave_recordsById(Map<String, Object> leave_records);

	/**
	 * @Description: 请假记录表删除
	 * @param: leave_id
	 *             包含请假记录表编号信的字符串对象
	 * @return: 整数 1==删除成功 0==删除失败
	 * @exception: 无
	 */
	public int deleteLeave_recordsByIds(String leave_id);
}

package com.example.factory.service;

import java.util.Map;

import com.example.factory.dto.PageDto;

/**
 * @Description: 加班记录Service接口
 * 
 * @author: 徐天鹏
 * @date: 2025/9/4
 * 
 */
public interface IOvertime_recordsService {

	/**
	 * @Description: 分页查询加班记录
	 * @param: keywords
	 *             查询条件关键字
	 * @param: pageNum
	 *             当前页数
	 * @param: maxPageNum
	 *             每页最多显示的记录数
	 * @return: dto对象
	 * @exception: 无
	 */
	public PageDto listOvertime_records(String keywords, int pageNum, int maxPageNum);

	/**
	 * @Description: 加班记录添加
	 * @param: overtime_records
	 *             包含加班记录信息的Map对象
	 * @return: 整数 1==添加成功 0==添加失败
	 * @exception: 无
	 */
	int addOvertime_records(Map<String, Object> overtime_records);

	/**
	 * @Description: 加班记录更新
	 * @param: overtime_records
	 *             包含加班记录信息的Map对象
	 * @return: 整数 1==更新成功 0==更新失败
	 * @exception: 无
	 */
	public int updateOvertime_recordsById(Map<String, Object> overtime_records);

	/**
	 * @Description: 加班记录删除
	 * @param: overtime_id
	 *             包含加班记录ID的字符串对象
	 * @return: 整数 1==删除成功 0==删除失败
	 * @exception: 无
	 */
	public int deleteOvertime_recordsByIds(String overtime_id);
}

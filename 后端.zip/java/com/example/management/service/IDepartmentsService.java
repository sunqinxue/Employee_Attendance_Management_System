package com.example.factory.service;

import java.util.Map;

import com.example.factory.dto.PageDto;

/**
 * @Description: 部门表Service接口
 * 
 * @author: 孙勤学
 * @date: 2025/9/4
 * 
 */
public interface IDepartmentsService {

	/**
	 * @Description: 分页查询部门表（单表）
	 * @param: keywords
	 *             查询条件关键字
	 * @param: pageNum
	 *             当前页数
	 * @param: maxPageNum
	 *             每页最多显示的记录数
	 * @return: dto对象
	 * @exception: 无
	 */
	public PageDto listDepartments(String keywords, int pageNum, int maxPageNum);

	/**
	 * @Description: 分页查询部门表（多表）
	 * @param: keywords
	 *             查询条件关键字
	 * @param: pageNum
	 *             当前页数
	 * @param: maxPageNum
	 *             每页最多显示的记录数
	 * @return: dto对象
	 * @exception: 无
	 */
	public PageDto listDepartments02(String keywords, int pageNum, int maxPageNum);

	/**
	 * @Description: 部门表添加
	 * @param: departments
	 *             包含部门表信息的Map对象
	 * @return: 整数 1==添加成功 0==添加失败
	 * @exception: 无
	 */
	int addDepartments(Map<String, Object> departments);

	/**
	 * @Description: 部门表更新
	 * @param: departments
	 *             包含部门表信息的Map对象
	 * @return: 整数 1==更新成功 0==更新失败
	 * @exception: 无
	 */
	public int updateDepartmentsById(Map<String, Object> departments);

	/**
	 * @Description: 部门表删除
	 * @param: department_id
	 *             包含部门表编号信息的字符串对象
	 * @return: 整数 1==删除成功 0==删除失败
	 * @exception: 无
	 */
	public int deleteDepartmentsByIds(String department_id);
}

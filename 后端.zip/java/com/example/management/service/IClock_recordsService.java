package com.example.factory.service;

import java.util.Map;

import com.example.factory.dto.PageDto;

/**
 * @Description: 打卡记录Service接口
 * 
 * @author: 孙勤学
 * @date: 2025/9/4
 * 
 */
public interface IClock_recordsService {

	/**
	 * @Description: 分页查询打卡记录
	 * @param: keywords
	 *             查询条件关键字
	 * @param: pageNum
	 *             当前页数
	 * @param: maxPageNum
	 *             每页最多显示的记录数
	 * @return: dto对象
	 * @exception: 无
	 */
	public PageDto listClock_records(String keywords, int pageNum, int maxPageNum);

	/**
	 * @Description: 打卡记录添加
	 * @param: clock_records
	 *             包含打卡记录信息的Map对象
	 * @return: 整数 1==添加成功 0==添加失败
	 * @exception: 无
	 */
	int addClock_records(Map<String, Object> clock_records);

	/**
	 * @Description: 打卡记录更新
	 * @param: clock_records
	 *             包含打卡记录，信息的Map对象
	 * @return: 整数 1==添加成功 0==添加失败
	 * @exception: 无
	 */
	public int updateClock_recordsById(Map<String, Object> clock_records);

	/**
	 * @Description: 打卡记录删除
	 * @param: record_id
	 *             包含打卡记录编号信的字符串对象
	 * @return: 整数 1==删除成功 0==删除失败
	 * @exception: 无
	 */
	public int deleteClock_recordsByIds(String record_id);
}

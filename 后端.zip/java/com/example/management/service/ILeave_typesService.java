package com.example.factory.service;

import java.util.Map;

import com.example.factory.dto.PageDto;

/**
 * @Description: 请假类型Service接口
 * 
 * @author: 孙勤学
 * @date: 2025/9/4
 * 
 */
public interface ILeave_typesService {

	/**
	 * @Description: 分页查询请假类型
	 * @param: keywords
	 *             查询条件关键字
	 * @param: pageNum
	 *             当前页数
	 * @param: maxPageNum
	 *             每页最多显示的记录数
	 * @return: dto对象
	 * @exception: 无
	 */
	public PageDto listLeave_types(String keywords, int pageNum, int maxPageNum);

	/**
	 * @Description: 请假类型添加
	 * @param: leave_types
	 *             包含请假类型信息的Map对象
	 * @return: 整数 1==添加成功 0==添加失败
	 * @exception: 无
	 */
	int addLeave_types(Map<String, Object> leave_types);

	/**
	 * @Description: 请假类型更新
	 * @param: leave_types
	 *             包含请假类型，信息的Map对象
	 * @return: 整数 1==添加成功 0==添加失败
	 * @exception: 无
	 */
	public int updateLeave_typesById(Map<String, Object> leave_types);

	/**
	 * @Description: 请假类型删除
	 * @param: type_id
	 *             包含请假类型编号信的字符串对象
	 * @return: 整数 1==删除成功 0==删除失败
	 * @exception: 无
	 */
	public int deleteLeave_typesByIds(String type_id);
}

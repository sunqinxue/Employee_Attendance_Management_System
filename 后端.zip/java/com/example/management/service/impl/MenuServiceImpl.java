package com.example.factory.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.factory.mapper.MenuMapper;
import com.example.factory.po.Menu;
import com.example.factory.po.User;
import com.example.factory.service.IMenuService;

/**
 * @Description: 菜单Service接口实现类
 * 
 * @author: 
 * 
 * @date: 
 */
@Service
public class MenuServiceImpl implements IMenuService {

	@Autowired
	MenuMapper sysMenuMapper;

	/**
	 * @Description: 根据角色Id查询角色对应的一级菜单
	 * @param: roleId 角色Id
	 * @return: 菜单对象集合
	 * @exception: 无
	 */
	public List<Menu> listMenu(int roleId) {
		return sysMenuMapper.listMenu(roleId);
	}

	/**
	 * @Description: 按用户名和密码查询 相应的对象==登录
	 * @param: keywords  用户名
	 * @param: keywords2 密码
	 * @return: 用户对象
	 * @exception: 无
	 */
	@Override
	public User login(String keywords, String keywords2) {
		return sysMenuMapper.login(keywords, keywords2);
	}
}

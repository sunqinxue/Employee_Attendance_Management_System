package com.example.factory.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.factory.dto.PageDto;
import com.example.factory.mapper.Overtime_recordsMapper;
import com.example.factory.po.Overtime_records;
import com.example.factory.service.IOvertime_recordsService;

/**
 * @Description: 加班记录Service接口实现类
 * 
 * @author: 徐天鹏
 * 
 * @date: 2025/9/4
 */
@Service
public class Overtime_recordsServiceImpl implements IOvertime_recordsService {

	@Autowired // DI 依赖注入注解
	Overtime_recordsMapper overtime_recordsMapper;

	/**
	 * @Description: 分页查询加班记录
	 * @param: keywords
	 *             查询条件关键字
	 * @param: pageNum
	 *             当前页数
	 * @param: maxPageNum
	 *             每页最多显示的记录数
	 * @return: dto对象
	 * @exception: 无
	 */
	@Override
	public PageDto listOvertime_records(String keywords, int pageNum, int maxPageNum) {
		int totalRow = 0; // 初始化总行数
		int totalPageNum = 0; // 初始化总页数
		int preNum = 0; // 初始化上一页
		int nextNum = 0; // 初始化下一页
		int beginNum = 0; // 初始化开始记录数

		PageDto pageDto = new PageDto();
		// 获取总行数
		totalRow = overtime_recordsMapper.getOvertime_recordsCount(keywords);
		// 如果查询行数为0，那么直接结束。
		if (totalRow == 0) {
			return pageDto;
		}
		// 计算总页数
		if (totalRow % maxPageNum == 0) {
			totalPageNum = totalRow / maxPageNum;
		} else {
			totalPageNum = totalRow / maxPageNum + 1;
		}
		// 当前页数验证
		if (pageNum <= 0) {
			pageNum = 1;
		}
		if (pageNum > totalPageNum) {
			pageNum = totalPageNum;
		}
		// 设置上一页和下一页
		preNum = pageNum;
		nextNum = pageNum;
		if (pageNum > 1) {
			preNum--;
		}
		if (pageNum < totalPageNum) {
			nextNum++;
		}
		// 计算开始查询记录数
		beginNum = (pageNum - 1) * maxPageNum;
		// 开始查询业务数据
		List<Overtime_records> list = overtime_recordsMapper.listOvertime_records(keywords, beginNum, maxPageNum);
		// 封装返回数据
		pageDto.setTotalRow(totalRow);
		pageDto.setTotalPageNum(totalPageNum);
		pageDto.setPreNum(preNum);
		pageDto.setNextNum(nextNum);
		pageDto.setPageNum(pageNum);
		pageDto.setMaxPageNum(maxPageNum);
		pageDto.setBeginNum(beginNum);
		pageDto.setList(list);
		return pageDto;
	}

	/**
	 * @Description: 加班记录添加
	 * @param: overtime_records
	 *             包含加班记录信息的Map对象
	 * @return: 整数 1==添加成功 0==添加失败
	 * @exception: 无
	 */
	@Override
	public int addOvertime_records(Map<String, Object> overtime_records) {
		return overtime_recordsMapper.addOvertime_records(overtime_records);
	}

	/**
	 * @Description: 加班记录更新
	 * @param: overtime_records
	 *             包含加班记录信息的Map对象
	 * @return: 整数 1==添加成功 0==添加失败
	 * @exception: 无
	 */
	@Override
	public int updateOvertime_recordsById(Map<String, Object> overtime_records) {
		return overtime_recordsMapper.updateOvertime_recordsById(overtime_records);
	}

	/**
	 * @Description: 加班记录删除
	 * @param: overtime_id
	 *             包含加班记录编号的字符串对象
	 * @return: 整数 1==删除成功 0==删除失败
	 * @exception: 无
	 */
	@Override
	public int deleteOvertime_recordsByIds(String overtime_id) {
		String[] split = overtime_id.split(",");
		int n = 0;
		for (String str : split) {
			n = overtime_recordsMapper.deleteOvertime_recordsByIds(str);
		}
		return n;
	}
}

package com.example.factory.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.factory.dto.PageDto;
import com.example.factory.mapper.Clock_recordsMapper;
import com.example.factory.po.Clock_records;
import com.example.factory.service.IClock_recordsService;

/**
 * @Description: 打卡记录Service接口实现类
 * 
 * @author: 孙勤学
 * 
 * @date: 2025/9/4
 */
@Service
public class Clock_recordsServiceImpl implements IClock_recordsService {

	@Autowired // DI 依赖注入注解
	Clock_recordsMapper clock_recordsMapper;

	/**
	 * @Description: 分页查询打卡记录
	 * @param: keywords
	 *             查询条件关键字
	 * @param: pageNum
	 *             当前页数
	 * @param: maxPageNum
	 *             每页最多显示的记录数
	 * @return: dto对象
	 * @exception: 无
	 */
	@Override
	public PageDto listClock_records(String keywords, int pageNum, int maxPageNum) {
		int totalRow = 0; // 初始化总行数
		int totalPageNum = 0; // 初始化总页数
		int preNum = 0; // 初始化上一页
		int nextNum = 0; // 初始化下一页
		int beginNum = 0; // 初始化开始记录数

		PageDto pageDto = new PageDto();
		// 获取总行数
		totalRow = clock_recordsMapper.getClock_recordsCount(keywords);// dao.getClock_recordsCount();//
		// 12
		// 如果查询行数为0，那么直接结束。
		if (totalRow == 0) {
			return pageDto;
		}
		// 计算总页数 21 % 5
		if (totalRow % maxPageNum == 0) {
			totalPageNum = totalRow / maxPageNum;
		} else {
			totalPageNum = totalRow / maxPageNum + 1; // 5
		}
		// 当前页数验证
		if (pageNum <= 0) {
			pageNum = 1;
		}
		if (pageNum > totalPageNum) {
			pageNum = totalPageNum;
		}
		// 设置上一页和下一页
		preNum = pageNum;
		nextNum = pageNum;
		if (pageNum > 1) {
			preNum--;
		}
		if (pageNum < totalPageNum) {
			nextNum++;
		}
		// 计算开始查询记录数
		beginNum = (pageNum - 1) * maxPageNum;
		// 开始查询业务数据
		List<Clock_records> list = clock_recordsMapper.listClock_records(keywords, beginNum, maxPageNum);
		// 封装返回数据
		pageDto.setTotalRow(totalRow);// totalRow
		pageDto.setTotalPageNum(totalPageNum);
		pageDto.setPreNum(preNum);
		pageDto.setNextNum(nextNum);
		pageDto.setPageNum(pageNum);
		pageDto.setMaxPageNum(maxPageNum);
		pageDto.setBeginNum(beginNum);
		pageDto.setList(list);
		return pageDto;
	}

	/**
	 * @Description: 打卡记录添加
	 * @param: clock_records
	 *             包含打卡记录信息的Map对象
	 * @return: 整数 1==添加成功 0==添加失败
	 * @exception: 无
	 */
	@Override
	public int addClock_records(Map<String, Object> clock_records) {
		return clock_recordsMapper.addClock_records(clock_records);
	}

	/**
	 * @Description: 打卡记录更新
	 * @param: clock_records
	 *             包含打卡记录信息的Map对象
	 * @return: 整数 1==添加成功 0==添加失败
	 * @exception: 无
	 */
	@Override
	public int updateClock_recordsById(Map<String, Object> clock_records) {
		return clock_recordsMapper.updateClock_recordsById(clock_records);
	}

	/**
	 * @Description: 打卡记录删除
	 * @param: record_id
	 *             包含打卡记录编号信的字符串对象
	 * @return: 整数 1==删除成功 0==删除失败
	 * @exception: 无
	 */
	@Override
	public int deleteClock_recordsByIds(String record_id) {
		String[] split = record_id.split(","); // 3,6,10
		int n = 0;
		for (String str : split) {
			n = clock_recordsMapper.deleteClock_recordsByIds(str);
		}
		return n;
	}
}
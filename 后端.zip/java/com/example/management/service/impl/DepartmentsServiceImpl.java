package com.example.factory.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.factory.dto.PageDto;
import com.example.factory.mapper.DepartmentsMapper;
import com.example.factory.po.Departments;
import com.example.factory.service.IDepartmentsService;

/**
 * @Description: 部门表Service接口实现类
 * 
 * @author: 孙勤学
 * 
 * @date: 2025/9/2
 */
@Service
public class DepartmentsServiceImpl implements IDepartmentsService {

	@Autowired // DI 依赖注入注解
	DepartmentsMapper departmentsMapper;

	/**
	 * @Description: 分页查询部门表（单表）
	 * @param: keywords
	 *             查询条件关键字
	 * @param: pageNum
	 *             当前页数
	 * @param: maxPageNum
	 *             每页最多显示的记录数
	 * @return: dto对象
	 * @exception: 无
	 */
	@Override
	public PageDto listDepartments(String keywords, int pageNum, int maxPageNum) {
		int totalRow = 0; // 初始化总行数
		int totalPageNum = 0; // 初始化总页数
		int preNum = 0; // 初始化上一页
		int nextNum = 0; // 初始化下一页
		int beginNum = 0; // 初始化开始记录数

		PageDto pageDto = new PageDto();
		// 获取总行数
		totalRow = departmentsMapper.getDepartmentsCount(keywords);
		// 如果查询行数为0，那么直接结束。
		if (totalRow == 0) {
			return pageDto;
		}
		// 计算总页数 21 % 5
		if (totalRow % maxPageNum == 0) {
			totalPageNum = totalRow / maxPageNum;
		} else {
			totalPageNum = totalRow / maxPageNum + 1; // 5
		}
		// 当前页数验证
		if (pageNum <= 0) {
			pageNum = 1;
		}
		if (pageNum > totalPageNum) {
			pageNum = totalPageNum;
		}
		// 设置上一页和下一页
		preNum = pageNum;
		nextNum = pageNum;
		if (pageNum > 1) {
			preNum--;
		}
		if (pageNum < totalPageNum) {
			nextNum++;
		}
		// 计算开始查询记录数
		beginNum = (pageNum - 1) * maxPageNum;
		// 开始查询业务数据
		List<Departments> list = departmentsMapper.listDepartments(keywords, beginNum, maxPageNum);
		// 封装返回数据
		pageDto.setTotalRow(totalRow);// totalRow
		pageDto.setTotalPageNum(totalPageNum);
		pageDto.setPreNum(preNum);
		pageDto.setNextNum(nextNum);
		pageDto.setPageNum(pageNum);
		pageDto.setMaxPageNum(maxPageNum);
		pageDto.setBeginNum(beginNum);
		pageDto.setList(list);
		return pageDto;
	}

	/**
	 * @Description: 分页查询部门表（多表）
	 * @param: keywords
	 *             查询条件关键字
	 * @param: pageNum
	 *             当前页数
	 * @param: maxPageNum
	 *             每页最多显示的记录数
	 * @return: dto对象
	 * @exception: 无
	 */
	@Override
	public PageDto listDepartments02(String keywords, int pageNum, int maxPageNum) {
		// TODO Auto-generated method stub
		int totalRow = 0; // 初始化总行数
		int totalPageNum = 0; // 初始化总页数
		int preNum = 0; // 初始化上一页
		int nextNum = 0; // 初始化下一页
		int beginNum = 0; // 初始化开始记录数

		PageDto pageDto = new PageDto();
		// 获取总行数
		totalRow = departmentsMapper.getDepartmentsCount02(keywords);
		// 如果查询行数为0，那么直接结束。
		if (totalRow == 0) {
			return pageDto;
		}
		// 计算总页数 21 % 5
		if (totalRow % maxPageNum == 0) {
			totalPageNum = totalRow / maxPageNum;
		} else {
			totalPageNum = totalRow / maxPageNum + 1; // 5
		}
		// 当前页数验证
		if (pageNum <= 0) {
			pageNum = 1;
		}
		if (pageNum > totalPageNum) {
			pageNum = totalPageNum;
		}
		// 设置上一页和下一页
		preNum = pageNum;
		nextNum = pageNum;
		if (pageNum > 1) {
			preNum--;
		}
		if (pageNum < totalPageNum) {
			nextNum++;
		}
		// 计算开始查询记录数
		beginNum = (pageNum - 1) * maxPageNum;
		// 开始查询业务数据
		List<Map<String, Object>> list = departmentsMapper.listDepartments02(keywords, beginNum, maxPageNum);
		// 封装返回数据
		pageDto.setTotalRow(totalRow);// totalRow
		pageDto.setTotalPageNum(totalPageNum);
		pageDto.setPreNum(preNum);
		pageDto.setNextNum(nextNum);
		pageDto.setPageNum(pageNum);
		pageDto.setMaxPageNum(maxPageNum);
		pageDto.setBeginNum(beginNum);
		pageDto.setList(list);
		return pageDto;
	}

	/**
	 * @Description: 部门表添加
	 * @param: departments
	 *             包含部门表信息的Map对象
	 * @return: 整数 1==添加成功 0==添加失败
	 * @exception: 无
	 */
	@Override
	public int addDepartments(Map<String, Object> departments) {
		return departmentsMapper.addDepartments(departments);
	}

	/**
	 * @Description: 部门表更新
	 * @param: departments
	 *             包含部门表信息的Map对象
	 * @return: 整数 1==更新成功 0==更新失败
	 * @exception: 无
	 */
	@Override
	public int updateDepartmentsById(Map<String, Object> departments) {
		return departmentsMapper.updateDepartmentsById(departments);
	}

	/**
	 * @Description: 部门表删除
	 * @param: department_id
	 *             包含部门表编号信息的字符串对象
	 * @return: 整数 1==删除成功 0==删除失败
	 * @exception: 无
	 */
	@Override
	public int deleteDepartmentsByIds(String department_id) {
		String[] split = department_id.split(","); // 3,6,10
		int n = 0;
		for (String str : split) {
			n = departmentsMapper.deleteDepartmentsByIds(str);
		}
		return n;
	}

}

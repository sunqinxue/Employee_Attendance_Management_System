package com.example.factory.service;

import java.util.Map;

import com.example.factory.dto.PageDto;

/**
 * @Description: 系统日志表Service接口
 * 
 * @author: 孙勤学
 * @date: 2025/9/4
 * 
 */
public interface ISystem_logsService {

	/**
	 * @Description: 分页查询系统日志表（单表）
	 * @param: keywords
	 *             查询条件关键字
	 * @param: pageNum
	 *             当前页数
	 * @param: maxPageNum
	 *             每页最多显示的记录数
	 * @return: dto对象
	 * @exception: 无
	 */
	public PageDto listSystem_logs(String keywords, int pageNum, int maxPageNum);

	/**
	 * @Description: 分页查询系统日志表（多表）
	 * @param: keywords
	 *             查询条件关键字
	 * @param: pageNum
	 *             当前页数
	 * @param: maxPageNum
	 *             每页最多显示的记录数
	 * @return: dto对象
	 * @exception: 无
	 */
	public PageDto listSystem_logs02(String keywords, int pageNum, int maxPageNum);

	/**
	 * @Description: 系统日志表添加
	 * @param: system_logs
	 *             包含系统日志表信息的Map对象
	 * @return: 整数 1==添加成功 0==添加失败
	 * @exception: 无
	 */
	int addSystem_logs(Map<String, Object> system_logs);

	/**
	 * @Description: 系统日志表更新
	 * @param: system_logs
	 *             包含系统日志表信息的Map对象
	 * @return: 整数 1==更新成功 0==更新失败
	 * @exception: 无
	 */
	public int updateSystem_logsById(Map<String, Object> system_logs);

	/**
	 * @Description: 系统日志表删除
	 * @param: logId
	 *             包含系统日志表编号的字符串对象
	 * @return: 整数 1==删除成功 0==删除失败
	 * @exception: 无
	 */
	public int deleteSystem_logsByIds(String logId);
}
package com.example.factory.service;

import java.util.Map;

import com.example.factory.dto.PageDto;

/**
 * @Description: 工厂Service接口
 * 
 * @author: 
 * 
 * @date: 
 * 
 */
public interface IFactoryService {

	/**
	 * @Description: 分页查询部门
	 * @param: keywords   查询条件关键字
	 * @param: pageNum    当前页数
	 * @param: maxPageNum 每页最多显示的记录数
	 * @return: dto对象
	 * @exception: 无
	 */
	public PageDto listFactory(String keywords, int pageNum, int maxPageNum);

	/**
	 * @Description: 根据user_id获取工厂记录
	 * @param: user_id 查询条件关键字
	 * @return: dto对象
	 * @exception: 无
	 */
	public PageDto listFactoryByUserid(String userId);

	/**
	 * @Description: 工厂添加
	 * @param: dept 包含部门信息的Map对象
	 * @return: 整数 1==添加成功 0==添加失败
	 * @exception: 无
	 */
	int addFactory(Map<String, Object> factory);

	/**
	 * @Description: 工厂更新
	 * @param: dept 包含部门信息的Map对象
	 * @return: 整数 1==添加成功 0==添加失败
	 * @exception: 无
	 */
	public int updateFactoryById(Map<String, Object> factory);

	/**
	 * @Description: 工厂删除
	 * @param: deptno 包含部门编号信的字符串对象
	 * @return: 整数 1==删除成功 0==删除失败
	 * @exception: 无
	 */
	public int deleteFactoryByIds(String id);
}

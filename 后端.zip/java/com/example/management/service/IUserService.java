package com.example.factory.service;

import java.util.Map;

import com.example.factory.dto.PageDto;
import com.example.factory.po.User;

/**
 * @Description: 用户Service接口
 * 
 * @author: 
 * 
 * @date: 
 * 
 */
public interface IUserService {

	/**
	 * @Description: 分页查询用户
	 * @param: keywords   查询条件关键字
	 * @param: pageNum    当前页数
	 * @param: maxPageNum 每页最多显示的记录数
	 * @return: dto对象
	 * @exception: 无
	 */
	public PageDto listUser(String keywords, int pageNum, int maxPageNum);

	/**
	 * @Description: 用户添加
	 * @param: dept 包含用户信息的Map对象
	 * @return: 整数 1==添加成功 0==添加失败
	 * @exception: 无
	 */
	int addUser(Map<String, Object> user);

	/**
	 * @Description: 用户添加 获取主键
	 * @param: dept 包含部门信息的Map对象
	 * @return: 整数 1==添加成功 0==添加失败
	 * @exception: 无
	 */
	public int addUser2(User user); // 好使的
	// public int addDept2(Map<String, Object> dept); //不行

	/**
	 * @Description: 用户更新
	 * @param: dept 包含用户信息的Map对象
	 * @return: 整数 1==添加成功 0==添加失败
	 * @exception: 无
	 */
	public int updateUserById(Map<String, Object> user);

	/**
	 * @Description: 用户删除
	 * @param: deptno 包含用户编号信的字符串对象
	 * @return: 整数 1==删除成功 0==删除失败
	 * @exception: 无
	 */
	public int deleteUserByIds(String id);
}

package com.example.factory.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.example.factory.po.Shifts;

/**
 * @Description: 班次表Mapper接口
 * 
 * @author: 孙勤学
 * 
 * @date: 2025/9/4
 */
@Mapper
public interface ShiftsMapper {

	/**
	 * @Description: 单条件获取班次表数量（单表）
	 * @param: keywords
	 *             查询条件关键字
	 * @return: 整数
	 * @exception: 无
	 */
	public int getShiftsCount(@Param("keywords") String keywords);

	/**
	 * @Description: 单条件获取班次表数量（多表）
	 * @param: keywords
	 *             查询条件关键字
	 * @return: 整数
	 * @exception: 无
	 */
	public int getShiftsCount02(@Param("keywords") String keywords);

	/**
	 * @Description: 单条件分页获取班次表记录（单表）
	 * @param: keywords
	 *             查询条件关键字
	 * @param: pageNum
	 *             起始页数
	 * @param: maxPageNum
	 *             每页最多显示的记录数
	 * @return: 班次表对象集合
	 * @exception: 无
	 */
	public List<Shifts> listShifts(@Param("keywords") String keywords, @Param("pageNum") int pageNum,
			@Param("maxPageNum") int maxPageNum);

	/**
	 * @Description: 单条件分页获取班次表记录（多表）
	 * @param: keywords
	 *             查询条件关键字
	 * @param: pageNum
	 *             起始页数
	 * @param: maxPageNum
	 *             每页最多显示的记录数
	 * @return: 班次表对象集合
	 * @exception: 无
	 */
	public List<Map<String, Object>> listShifts02(@Param("keywords") String keywords, @Param("pageNum") int pageNum,
			@Param("maxPageNum") int maxPageNum);

	/**
	 * @Description: 班次表添加
	 * @param: shifts
	 *             包含班次表信息的Map对象
	 * @return: 整数1 为成功
	 * @exception: 无
	 */
	public int addShifts(Map<String, Object> shifts);

	/**
	 * @Description: 班次表更新
	 * @param: 包含班次表信息的Map对象
	 * @return: 整数1 为成功
	 * @exception: 无
	 */
	public int updateShiftsById(Map<String, Object> shifts);

	/**
	 * @Description: 班次表删除
	 * @param: shift_id
	 *             包含班次表编号信的字符串对象
	 * @return: 整数1 为成功
	 * @exception: 无
	 */
	public int deleteShiftsByIds(String shift_id);
}
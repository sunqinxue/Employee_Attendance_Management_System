package com.example.factory.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

// 导入部门表的POJO实体类（必须确保POJO类路径正确，若路径不同需修改）
import com.example.factory.po.Departments;

/**
 * @Description: 部门表Mapper接口（原“班次表”注释修正）
 * 
 * @author: 孙勤学
 * 
 * @date: 2025/9/4
 */
// 1. 接口名修正：MyBatis Mapper接口需遵循“表名+Mapper”规范，原“Departments”改为“DepartmentsMapper”
@Mapper
public interface DepartmentsMapper {

	/**
	 * @Description: 单条件获取部门表数量（单表）（原“班次表”注释修正）
	 * @param: keywords
	 *             查询条件关键字
	 * @return: 整数（部门记录总数）
	 * @exception: 无
	 */
	public int getDepartmentsCount(@Param("keywords") String keywords);

	/**
	 * @Description: 单条件获取部门表数量（多表）（原“班次表”注释修正）
	 * @param: keywords
	 *             查询条件关键字
	 * @return: 整数（多表关联后的部门记录总数）
	 * @exception: 无
	 */
	public int getDepartmentsCount02(@Param("keywords") String keywords);

	/**
	 * @Description: 单条件分页获取部门表记录（单表）（原“班次表”注释修正）
	 * @param: keywords
	 *             查询条件关键字
	 * @param: pageNum
	 *             起始记录索引（注：若XML中是“limit
	 *             #{pageNum},#{maxPageNum}”，此处实际是“起始索引”，非“页数”，注释需准确）
	 * @param: maxPageNum
	 *             每页最多显示的记录数
	 * @return: 部门表实体对象集合（原“班次表对象集合”修正）
	 * @exception: 无
	 */
	// 2.
	// 返回类型修正：原“List<Departments>”依赖正确导入的POJO类，需确保com.example.factory.po.Departments存在
	public List<Departments> listDepartments(@Param("keywords") String keywords, @Param("pageNum") int pageNum,
			@Param("maxPageNum") int maxPageNum);

	/**
	 * @Description: 单条件分页获取部门表记录（多表）（原“班次表”注释修正）
	 * @param: keywords
	 *             查询条件关键字
	 * @param: pageNum
	 *             起始记录索引（同单表，注释修正）
	 * @param: maxPageNum
	 *             每页最多显示的记录数
	 * @return: 部门表多表关联结果集合（Map格式）（原“班次表对象集合”修正）
	 * @exception: 无
	 */
	public List<Map<String, Object>> listDepartments02(@Param("keywords") String keywords,
			@Param("pageNum") int pageNum, @Param("maxPageNum") int maxPageNum);

	/**
	 * @Description: 部门表添加（原“班次表添加”注释修正）
	 * @param: departments
	 *             包含部门表信息的Map对象（原“shifts”参数名修正，与方法名、表名一致）
	 * @return: 整数 1==添加成功
	 * @exception: 无
	 */
	public int addDepartments(Map<String, Object> departments);

	/**
	 * @Description: 部门表更新（原“班次表更新”注释修正）
	 * @param: departments
	 *             包含部门表信息的Map对象（原无参数名+首字母大写“Departments”修正，符合小驼峰规范）
	 * @return: 整数 1==更新成功
	 * @exception: 无
	 */
	// 3. 参数名修正：原“Map<String, Object> Departments”首字母大写不符合规范，改为“departments”
	public int updateDepartmentsById(Map<String, Object> departments);

	/**
	 * @Description: 部门表删除（原“班次表删除”注释修正）
	 * @param: department_id
	 *             包含部门表编号的字符串对象（原“departments_id”复数修正，单个ID参数用单数，批量删除时也对应单个ID拆分）
	 * @return: 整数 1==删除成功
	 * @exception: 无
	 */
	// 4.
	// 参数名修正：原“departments_id”（复数）改为“department_id”（单数，与数据库字段“department_id”完全一致）
	public int deleteDepartmentsByIds(String department_id);
}
package com.example.factory.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.example.factory.po.Overtime_records;

/**
 * @Description: 加班记录Mapper接口
 * 
 * @author: 徐天鹏
 * 
 * @date: 2025/9/4
 */
@Mapper
public interface Overtime_recordsMapper {

	/**
	 * @Description: 单条件获取加班记录数量
	 * @param: keywords
	 *             查询条件关键字
	 * @return: 整数
	 * @exception: 无
	 */
	public int getOvertime_recordsCount(@Param("keywords") String keywords);

	/**
	 * @Description: 单条件分页获取加班记录记录
	 * @param: keywords
	 *             查询条件关键字
	 * @param: pageNum
	 *             起始页数
	 * @param: maxPageNum
	 *             每页最多显示的记录数
	 * @return: 加班记录对象集合
	 * @exception: 无
	 */
	public List<Overtime_records> listOvertime_records(@Param("keywords") String keywords,
			@Param("pageNum") int pageNum, @Param("maxPageNum") int maxPageNum);

	/**
	 * @Description: 加班记录添加
	 * @param: overtime_records
	 *             包含加班记录信息的Map对象
	 * @return: 整数1 为成功
	 * @exception: 无
	 */
	public int addOvertime_records(Map<String, Object> overtime_records);

	/**
	 * @Description: 加班记录更新
	 * @param: overtime_records
	 *             包含加班记录信息的Map对象
	 * @return: 整数1 为成功
	 * @exception: 无
	 */
	public int updateOvertime_recordsById(Map<String, Object> overtime_records);

	/**
	 * @Description: 加班记录删除
	 * @param: record_id
	 *             包含加班记录编号信的字符串对象
	 * @return: 整数1 为成功
	 * @exception: 无
	 */
	public int deleteOvertime_recordsByIds(String record_id);
}
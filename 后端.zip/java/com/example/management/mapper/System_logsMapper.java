package com.example.factory.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.example.factory.po.System_logs;

/**
 * @Description: 系统日志表Mapper接口
 * 
 * @author: 刘翼鸣
 * 
 * @date: 2025/9/4
 */
@Mapper
public interface System_logsMapper {

	/**
	 * @Description: 单条件获取系统日志表数量（单表）
	 * @param: keywords
	 *             查询条件关键字
	 * @return: 整数
	 * @exception: 无
	 */
	public int getSystem_logsCount(@Param("keywords") String keywords);

	/**
	 * @Description: 单条件获取系统日志表数量（多表）
	 * @param: keywords
	 *             查询条件关键字
	 * @return: 整数
	 * @exception: 无
	 */

	public int getSystem_logsCount02(@Param("keywords") String keywords);

	/**
	 * @Description: 单条件分页获取系统日志表记录（单表）
	 * @param: keywords
	 *             查询条件关键字
	 * @param: pageNum
	 *             起始页数
	 * @param: maxPageNum
	 *             每页最多显示的记录数
	 * @return: 系统日志表对象集合
	 * @exception: 无
	 */
	public List<System_logs> listSystem_logs(@Param("keywords") String keywords, @Param("pageNum") int pageNum,
			@Param("maxPageNum") int maxPageNum);

	/**
	 * @Description: 单条件分页获取系统日志表记录（多表）
	 * @param: keywords
	 *             查询条件关键字
	 * @param: pageNum
	 *             起始页数
	 * @param: maxPageNum
	 *             每页最多显示的记录数
	 * @return: 系统日志表对象集合
	 * @exception: 无
	 */
	public List<Map<String, Object>> listSystem_logs02(@Param("keywords") String keywords,
			@Param("pageNum") int pageNum, @Param("maxPageNum") int maxPageNum);

	/**
	 * @Description: 系统日志表添加
	 * @param: system_logs
	 *             包含系统日志表信息的Map对象
	 * @return: 整数1 为成功
	 * @exception: 无
	 */
	public int addSystem_logs(Map<String, Object> system_logs);

	/**
	 * @Description: 系统日志表更新
	 * @param: system_logs
	 *             包含系统日志表信息的Map对象
	 * @return: 整数1 为成功
	 * @exception: 无
	 */
	public int updateSystem_logsById(Map<String, Object> system_logs);

	/**
	 * @Description: 系统日志表删除
	 * @param: log_id
	 *             包含系统日志编号的字符串对象
	 * @return: 整数1 为成功
	 * @exception: 无
	 */
	public int deleteSystem_logsByIds(String log_id);
}
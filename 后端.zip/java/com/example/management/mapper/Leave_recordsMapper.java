package com.example.factory.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.example.factory.po.Leave_records;

/**
 * @Description: 请假记录Mapper接口
 * 
 * @author: 徐天鹏
 * 
 * @date: 2025/9/4
 */
@Mapper
public interface Leave_recordsMapper {

	/**
	 * @Description: 单条件获取请假记录数量（单表）
	 * @param: keywords
	 *             查询条件关键字
	 * @return: 整数
	 * @exception: 无
	 */
	public int getLeave_recordsCount(@Param("keywords") String keywords);

	/**
	 * @Description: 单条件获取请假记录数量（多表）
	 * @param: keywords
	 *             查询条件关键字
	 * @return: 整数
	 * @exception: 无
	 */
	public int getLeave_recordsCount02(@Param("keywords") String keywords);

	/**
	 * @Description: 单条件分页获取请假记录记录（单表）
	 * @param: keywords
	 *             查询条件关键字
	 * @param: pageNum
	 *             起始页数
	 * @param: maxPageNum
	 *             每页最多显示的记录数
	 * @return: 请假记录对象集合
	 * @exception: 无
	 */
	public List<Leave_records> listLeave_records(@Param("keywords") String keywords, @Param("pageNum") int pageNum,
			@Param("maxPageNum") int maxPageNum);

	/**
	 * @Description: 单条件分页获取请假记录记录（多表）
	 * @param: keywords
	 *             查询条件关键字
	 * @param: pageNum
	 *             起始页数
	 * @param: maxPageNum
	 *             每页最多显示的记录数
	 * @return: 请假记录对象集合
	 * @exception: 无
	 */
	public List<Map<String, Object>> listLeave_records02(@Param("keywords") String keywords,
			@Param("pageNum") int pageNum, @Param("maxPageNum") int maxPageNum);

	/**
	 * @Description: 请假记录添加
	 * @param: Leave_records
	 *             包含请假记录信息的Map对象
	 * @return: 整数1 为成功
	 * @exception: 无
	 */
	public int addLeave_records(Map<String, Object> Leave_records);

	/**
	 * @Description: 请假记录更新
	 * @param: 包含请假记录信息的Map对象
	 * @return: 整数1 为成功
	 * @exception: 无
	 */
	public int updateLeave_recordsById(Map<String, Object> Leave_records);

	/**
	 * @Description: 请假记录删除
	 * @param: leave_id
	 *             包含请假记录编号信的字符串对象
	 * @return: 整数1 为成功
	 * @exception: 无
	 */
	public int deleteLeave_recordsByIds(String leave_id);
}
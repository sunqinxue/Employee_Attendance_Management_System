package com.example.factory.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.example.factory.po.Factory;

/**
 * @Description: 工厂Mapper接口
 * 
 * @author:
 * 
 * @date: 
 */
@Mapper
public interface FactoryMapper {

	/**
	 * @Description: 单条件获取工厂数量
	 * @param: keywords 查询条件关键字
	 * @return: 整数
	 * @exception: 无
	 */
	public int getFactoryCount(@Param("keywords") String keywords);

	/**
	 * @Description: 单条件分页获取工厂记录
	 * @param: keywords   查询条件关键字
	 * @param: pageNum    起始页数
	 * @param: maxPageNum 每页最多显示的记录数
	 * @return: 部门对象集合
	 * @exception: 无
	 */
	public List<Factory> listFactory(@Param("keywords") String keywords, @Param("pageNum") int pageNum,
			@Param("maxPageNum") int maxPageNum);

	/**
	 * @Description: 根据user_id获取工厂记录
	 * @param: user_id 查询条件关键字
	 * @return: 工厂对象集合
	 * @exception: 无
	 */
	public List<Factory> listFactoryByUserid(@Param("user_id") String user_id); // 必须加 @Param("user_id")

	/**
	 * @Description: 工厂添加
	 * @param: factory 包含部门信息的Map对象
	 * @return: 整数1 为成功
	 * @exception: 无
	 */
	public int addFactory(Map<String, Object> factory);

	/**
	 * @Description: 工厂更新
	 * @param: factory 包含部门信息的Map对象
	 * @return: 整数1 为成功
	 * @exception: 无
	 */
	public int updateFactoryById(Map<String, Object> factory);

	/**
	 * @Description: 工厂删除
	 * @param: deptno 包含部门编号信的字符串对象
	 * @return: 整数1 为成功
	 * @exception: 无
	 */
	public int deleteFactoryByIds(String id);
}
package com.example.factory.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.example.factory.po.Leave_types;

/**
 * @Description: 请假类型Mapper接口
 * 
 * @author: 孙勤学
 * 
 * @date: 2025/9/4
 */
@Mapper
public interface Leave_typesMapper {

	/**
	 * @Description: 单条件获取请假类型数量
	 * @param: keywords
	 *             查询条件关键字
	 * @return: 整数
	 * @exception: 无
	 */
	public int getLeave_typesCount(@Param("keywords") String keywords);

	/**
	 * @Description: 单条件分页获取请假类型记录
	 * @param: keywords
	 *             查询条件关键字
	 * @param: pageNum
	 *             起始页数
	 * @param: maxPageNum
	 *             每页最多显示的记录数
	 * @return: 请假类型对象集合
	 * @exception: 无
	 */
	public List<Leave_types> listLeave_types(@Param("keywords") String keywords, @Param("pageNum") int pageNum,
			@Param("maxPageNum") int maxPageNum);

	/**
	 * @Description: 请假类型添加
	 * @param: leave_types
	 *             包含请假类型信息的Map对象
	 * @return: 整数1 为成功
	 * @exception: 无
	 */
	public int addLeave_types(Map<String, Object> leave_types);

	/**
	 * @Description: 请假类型更新
	 * @param: leave_types
	 *             包含请假类型信息的Map对象
	 * @return: 整数1 为成功
	 * @exception: 无
	 */
	public int updateLeave_typesById(Map<String, Object> leave_types);

	/**
	 * @Description: 请假类型删除
	 * @param: type_id
	 *             包含请假类型编号信的字符串对象
	 * @return: 整数1 为成功
	 * @exception: 无
	 */
	public int deleteLeave_typesByIds(String type_id);
}
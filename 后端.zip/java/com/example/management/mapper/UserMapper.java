package com.example.factory.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.example.factory.po.User;

/**
 * @Description: 用户Mapper接口
 * 
 * @author: 
 * 
 * @date: 
 */
@Mapper
public interface UserMapper {

	/**
	 * @Description: 单条件获取用户数量
	 * @param: keywords 查询条件关键字
	 * @return: 整数
	 * @exception: 无
	 */
	public int getUserCount(@Param("keywords") String keywords);

	/**
	 * @Description: 单条件分页获取用户记录
	 * @param: keywords   查询条件关键字
	 * @param: pageNum    起始页数
	 * @param: maxPageNum 每页最多显示的记录数
	 * @return: 部门对象集合
	 * @exception: 无
	 */
	public List<User> listUser(@Param("keywords") String keywords, @Param("pageNum") int pageNum,
			@Param("maxPageNum") int maxPageNum);

	/**
	 * @Description: 用户
	 * @param: dept 包含用户信息的Map对象
	 * @return: 整数1 为成功
	 * @exception: 无
	 */
	public int addUser(Map<String, Object> user);

	/**
	 * @Description: 部门用户 获取主键
	 * @param: dept 包含部门信息的Map对象
	 * @return: 整数1 为成功
	 * @exception: 无
	 */

	public int addUser2(User user); // 好使的

	/**
	 * @Description: 用户更新
	 * @param: dept 包含部门信息的Map对象
	 * @return: 整数1 为成功
	 * @exception: 无
	 */
	public int updateUserById(Map<String, Object> user);

	/**
	 * @Description: 用户删除
	 * @param: deptno 包含用户编号信的字符串对象
	 * @return: 整数1 为成功
	 * @exception: 无
	 */
	public int deleteUserByIds(String id);
}
package com.example.factory.po;

/**
 * @Description: 工厂实体类
 * 
 * @author: 
 *
 * @date: 
 */
public class Factory {
	private Integer id;
	private String factory_name;
	private String factory_profile;
	private Integer factory_status;
	private Integer user_id;
	private String contact_info;
	private String contacts;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getFactory_name() {
		return factory_name;
	}

	public void setFactory_name(String factory_name) {
		this.factory_name = factory_name;
	}

	public String getFactory_profile() {
		return factory_profile;
	}

	public void setFactory_profile(String factory_profile) {
		this.factory_profile = factory_profile;
	}

	public Integer getFactory_status() {
		return factory_status;
	}

	public void setFactory_status(Integer factory_status) {
		this.factory_status = factory_status;
	}

	public Integer getUser_id() {
		return user_id;
	}

	public void setUser_id(Integer user_id) {
		this.user_id = user_id;
	}

	public String getContact_info() {
		return contact_info;
	}

	public void setContact_info(String contact_info) {
		this.contact_info = contact_info;
	}

	public String getContacts() {
		return contacts;
	}

	public void setContacts(String contacts) {
		this.contacts = contacts;
	}
}
package com.example.factory.po;

/**
 * @Description: 部门实体类
 * 
 * @author: 刘康生
 * 
 * @date: 2025/9/2
 */
public class Departments {// department_id, department_name, parent_id,
							// manager_id,created_time
	private Integer department_id;
	private String department_name;
	private Integer parent_id;
	private Integer manager_id;
	private String created_time;

	public Integer getDepartment_id() {
		return department_id;
	}

	public void setDepartment_id(Integer department_id) {
		this.department_id = department_id;
	}

	public String getDepartment_name() {
		return department_name;
	}

	public void setDepartment_name(String department_name) {
		this.department_name = department_name;
	}

	public Integer getParent_id() {
		return parent_id;
	}

	public void setParent_id(Integer parent_id) {
		this.parent_id = parent_id;
	}

	public Integer getManager_id() {
		return manager_id;
	}

	public void setManager_id(Integer manager_id) {
		this.manager_id = manager_id;
	}

	public String getCreated_time() {
		return created_time;
	}

	public void setCreated_time(String created_time) {
		this.created_time = created_time;
	}

}
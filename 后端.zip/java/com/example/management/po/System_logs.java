package com.example.factory.po;

/**
 * @Description: 系统日志实体类（对应表system_logs）
 * 
 * @author: 孙勤学
 * 
 * @date: 2025/9/2
 */
public class System_logs { // 修正类名，符合驼峰命名规范
	private Integer log_id;
	private Integer user_id;
	private String action_type;
	private String action_details;
	private String ip_address;
	private String created_time; // 修正为日期时间类型

	public Integer getLog_id() {
		return log_id;
	}

	public void setLog_id(Integer log_id) {
		this.log_id = log_id;
	}

	public Integer getUser_id() {
		return user_id;
	}

	public void setUser_id(Integer user_id) {
		this.user_id = user_id;
	}

	public String getAction_type() {
		return action_type;
	}

	public void setAction_type(String action_type) {
		this.action_type = action_type;
	}

	public String getAction_details() {
		return action_details;
	}

	public void setAction_details(String action_details) {
		this.action_details = action_details;
	}

	public String getIp_address() {
		return ip_address;
	}

	public void setIp_address(String ip_address) {
		this.ip_address = ip_address;
	}

	public String getCreated_time() {
		return created_time;
	}

	public void setCreated_time(String created_time) {
		this.created_time = created_time;
	}

}
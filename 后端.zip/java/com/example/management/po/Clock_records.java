package com.example.factory.po;

/**
 * @Description: 打卡记录实体类
 * 
 * @author: 孙勤学
 * 
 * @date: 2025/9/4
 */
public class Clock_records {// employee_id, clock_time, device_id, location,
							// type, status
	private Integer record_id;
	private Integer employee_id;
	private String clock_time;
	private String device_id;
	private String location;
	private String type;
	private String status;
	private String created_time;

	public String getCreated_time() {
		return created_time;
	}

	public void setCreated_time(String created_time) {
		this.created_time = created_time;
	}

	public Integer getRecord_id() {
		return record_id;
	}

	public void setRecord_id(Integer record_id) {
		this.record_id = record_id;
	}

	public Integer getEmployee_id() {
		return employee_id;
	}

	public void setEmployee_id(Integer employee_id) {
		this.employee_id = employee_id;
	}

	public String getClock_time() {
		return clock_time;
	}

	public void setClock_time(String clock_time) {
		this.clock_time = clock_time;
	}

	public String getDevice_id() {
		return device_id;
	}

	public void setDevice_id(String device_id) {
		this.device_id = device_id;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
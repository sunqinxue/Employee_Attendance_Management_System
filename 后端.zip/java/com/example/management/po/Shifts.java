package com.example.factory.po;

/**
 * @Description: 部门实体类
 * 
 * @author: 孙勤学
 * 
 * @date: 2025/9/2
 */
public class Shifts {// shift_name, start_time, end_time, flexible_minutes
	private Integer shift_id;
	private String shift_name;
	private String start_time;
	private String end_time;
	private String flexible_minutes;
	private String created_time;

	public String getCreated_time() {
		return created_time;
	}

	public void setCreated_time(String created_time) {
		this.created_time = created_time;
	}

	public Integer getShift_id() {
		return shift_id;
	}

	public void setShift_id(Integer shift_id) {
		this.shift_id = shift_id;
	}

	public String getShift_name() {
		return shift_name;
	}

	public void setShift_name(String shift_name) {
		this.shift_name = shift_name;
	}

	public String getStart_time() {
		return start_time;
	}

	public void setStart_time(String start_time) {
		this.start_time = start_time;
	}

	public String getEnd_time() {
		return end_time;
	}

	public void setEnd_time(String end_time) {
		this.end_time = end_time;
	}

	public String getFlexible_minutes() {
		return flexible_minutes;
	}

	public void setFlexible_minutes(String flexible_minutes) {
		this.flexible_minutes = flexible_minutes;
	}

}
package com.example.factory.po;

/**
 * @Description: 请假类型实体类
 * 
 * @author: 孙勤学
 * 
 * @date: 2025/9/4
 */
public class Leave_types { //// type_id,type_name, deduct_policy, requires_proof
	private Integer type_id;
	private String type_name;
	private String deduct_policy;
	private String created_time;

	public String getCreated_time() {
		return created_time;
	}

	public void setCreated_time(String created_time) {
		this.created_time = created_time;
	}

	public Integer getType_id() {
		return type_id;
	}

	public void setType_id(Integer type_id) {
		this.type_id = type_id;
	}

	public String getType_name() {
		return type_name;
	}

	public void setType_name(String type_name) {
		this.type_name = type_name;
	}

	public String getDeduct_policy() {
		return deduct_policy;
	}

	public void setDeduct_policy(String deduct_policy) {
		this.deduct_policy = deduct_policy;
	}

	public String getRequires_proof() {
		return requires_proof;
	}

	public void setRequires_proof(String requires_proof) {
		this.requires_proof = requires_proof;
	}

	private String requires_proof;

}
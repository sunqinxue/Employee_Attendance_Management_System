package com.example.factory.po;

/**
 * @Description: 加班记录实体类
 * 
 * @author: 徐天鹏
 * 
 * @date: 2025/9/4
 */
public class Overtime_records {// employee_id, start_time, end_time, duration,
								// multiplier, status
								// overtime_id,created_time
	private Integer overtime_id;
	private Integer employee_id;
	private String start_time;
	private String end_time;
	private String duration;
	private String multiplier;
	private String status;
	private String created_time;

	public Integer getOvertime_id() {
		return overtime_id;
	}

	public void setOvertime_id(Integer overtime_id) {
		this.overtime_id = overtime_id;
	}

	public Integer getEmployee_id() {
		return employee_id;
	}

	public void setEmployee_id(Integer employee_id) {
		this.employee_id = employee_id;
	}

	public String getStart_time() {
		return start_time;
	}

	public void setStart_time(String start_time) {
		this.start_time = start_time;
	}

	public String getEnd_time() {
		return end_time;
	}

	public void setEnd_time(String end_time) {
		this.end_time = end_time;
	}

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	public String getMultiplier() {
		return multiplier;
	}

	public void setMultiplier(String multiplier) {
		this.multiplier = multiplier;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getCreated_time() {
		return created_time;
	}

	public void setCreated_time(String created_time) {
		this.created_time = created_time;
	}

}
package com.example.util;

public class Test01 {

	static int a1 = 1;

	static void a() {
		System.out.println(a1);
	}

	static int a2 = 2;

	static void a2() {
		System.out.println(a2);
	}

	public static void main(String[] args) {
		a();
		a2();
	}

}

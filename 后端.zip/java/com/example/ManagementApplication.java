package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

/**
 * @Description: SpringBoot启动类
 * 
 * @author: factory
 * 
 * @date: 
 * 
 */
@SpringBootApplication
public class FactoryApplication extends SpringBootServletInitializer {
	public static void main(String[] args) {
		SpringApplication.run(FactoryApplication.class, args);
	}

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
		return builder.sources(FactoryApplication.class);
	}
}

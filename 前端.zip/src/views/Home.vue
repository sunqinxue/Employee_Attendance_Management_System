<!-- 
  @Description: 前端首页
  @author 
  @date 
-->
<template>
	<div class="common-layout">
	    <el-container>
		    <el-header class="c3">
				<h3>员工打卡情况管理系统</h3>
			    <span class="c1">【{{currentUserName}}】欢迎您的登录</span>
				<a class="c2" href="http://localhost:8080/">退出</a>
			</el-header>
	        <el-container>
				 <el-aside width="300px" class="c4">
					<el-tree :data="data33" :props="defaultProps" 
						@node-click="handleNodeClick" />
					<br/>
				 </el-aside>
				 <el-main  class="c5">
					 <router-view></router-view>
				 </el-main>
	       </el-container>
		   <el-footer class="c6"></el-footer>
	    </el-container>
	</div>
</template>
<!--javaScript代码部分-->
<script>
    import axios from 'axios';
	let RoleID;
	export default {
		mounted(){ //mounted==DOM挂载完毕后自动执行
			let ss =sessionStorage.getItem("name");
			this.currentUserName = ss;
			//alert(ss);
		},
		methods: {
			handleNodeClick(data) {
				//某个节点被点击后，拿到url跳转路由即可
				this.$router.push(data.url)
			}
		},
		created() { //created==实例创建完毕
			let _this = this;
			let roleID = sessionStorage.getItem("RoleID");
		    let url = "http://localhost:7070/newMenu/listMenu?roleId="+roleID;
		    axios.get(url).then(function(res) {
		    	let sz_str;
		        //把后台传过来的JSON对象变成JSON字符串
		    	let str = JSON.stringify(res.data);
		    	//把JSON字符串变成前台能识别的JSON对象
		    	let obj = JSON.parse(str);
				for(let k=0;k<obj.length;k++) {   //1级菜单    menu_name
		    		sz_str= sz_str + '{"label":'+ '"' +obj[k].menu_name + '", "url":"' 
					+ obj[k].url +'"},';
		    		for(let i=0;i<obj[k].childMenu.length;i++) { //2级菜单
		    			if(obj[k].childMenu.length > 0) {
		    				if(i==0)
		    				   sz_str= sz_str.substring(0,sz_str.length-2) + ',"children":[{"label":"'+obj[k].childMenu[i].menu_name+'","url":"'
							   +obj[k].childMenu[i].url+'"},';
		    				else //menu_name
		    				   sz_str= sz_str + '{"label":"'+obj[k].childMenu[i].menu_name
							   +'","url":"'+obj[k].childMenu[i].url+'"},';				
		    			}
		    			//以下第三级菜单
		    			if(obj[k].childMenu[i].childMenu.length > 0) {
							//3级菜单
		    				for(let j=0;j<obj[k].childMenu[i].childMenu.length;j++) { 
		    					  if(j==0)  //menu_name
		    						 sz_str= sz_str.substring(0,sz_str.length-2) 
									 + ',"children":[{"label":"'
									 +obj[k].childMenu[i].childMenu[j].menu_name+'","url":"'
									 +obj[k].childMenu[i].childMenu[j].url+'"},';
		    					  else  //menu_name
		    						 sz_str= sz_str + '{"label":"'
									 +obj[k].childMenu[i].childMenu[j].menu_name
									 +'","url":"'+obj[k].childMenu[i].childMenu[j].url
									 +'"},';			
		    			    }
							if(obj[k].childMenu[i].childMenu.length > 0)
							    sz_str= sz_str.substring(0,sz_str.length-1) + ']},';  
		    			}
		    		}
		    		if(obj[k].childMenu.length > 0) 
		    		   sz_str= sz_str.substring(0,sz_str.length-1) + ']},';
		    	}
				//去掉前面的undefined
		    	sz_str = sz_str.substr(sz_str.indexOf("{"), sz_str.length);
		    	//前后加上 '['   ']'
		    	sz_str = '[' + sz_str.substring(0,sz_str.length-1) + ']';
				console.log("sz_str="+sz_str);
		    	_this.data33 =  JSON.parse(sz_str);
	        })
			
			//判断如果是工厂管理员则查询工厂id,并把工厂id存入sessionStorage; 否则把sessionStorage中的工厂id 设置=0
			//roleID == 2
			// if(roleID == 3) {
			// 	let id = sessionStorage.getItem("id");
			// 	console.log("AAA id="+id);
			// 	let url = "http://localhost:7070/newFactory/listFactoryByUserid?user_id="+id;
			// 	//let url = "http://localhost:7821/newFactory/listFactoryByUserid?userId="+id;
			// 	axios.get(url).then(resp=> {  //箭头函数
			// 		_this.adminData = resp.data.list;
			// 		console.log("fid="+_this.adminData[0].id);
			// 		//把工厂id 存入sessionStorage
			// 		sessionStorage.setItem("fid", _this.adminData[0].id);
			// 	});
			// } else {
			// 		sessionStorage.setItem("fid", 0);
			// }
		},
		//vue的数据区
		data() {
			return {
				defaultProps: {
				    children: 'children',
				    label: 'label',
					url:''
				},
				data33: [{label:'系统管理(无后端数据)', url:''}],
				currentUserName: '',
			}
		}
	}
</script>
<!--css样式表部分-->
<style>
	.el-header{
		line-height: 20px;
		background-color: papayawhip;
		padding-top: 1px;
	} 
	.el-aside{
		background-color: lightblue;
		height: 680px;
	}
	.el-footer{
		line-height: 80px;
		background-color: pink;
	}
	.el-tree {
		background-color: lightblue;
	}
	.c1{
		position: absolute;
		top:48px;
		right: 200px;
	}
	.c2{
		position: absolute;
		top:48px;
		right: 50px;
	}
	.c3{
		/* 顶部  no-repeat */
		background: url("../assets/主页1.png") repeat top center;
	}
	.c4{
		/* 左边 */
		/* no-repeat top center;  opacity: 0.1;  du159.jpg*/
		background: url("../assets/主页1.png") no-repeat top center;
	}
	.c5{
		/* 中间 */
		/* display: flex;  弹性布局  */
	    /* flex-wrap: wrap; 换行 */
		/*
			background-color: #CAC6C6;   map1.jpg  girl3.jpg  du147.png  no-repeat top center
		*/
	    background: url("../assets/map1.jpg") repeat top left ;
    }
	.c6{
		/* 底部  no-repeat */
		background: url("../assets/主页3.png") repeat top center;
	}
</style>
<!-- 
  @Description: 前端登录页面
  @author 
  @date 
-->
<!--template 是vue的模板-->
<template class="c1">
  <!-- el-form是element UI里的表单组件 -->
  <el-form  class="login-container" label-position="left"
           label-width="0px" v-loading="loading" >
    <h3 class="login_title">员工打卡情况管理系统--登录</h3>
    <el-form-item prop="account">
      <el-input type="text" v-model="loginForm.username"  style="width:100%"
	  auto-complete="off" placeholder="用户名"></el-input>
    </el-form-item>
    <el-form-item prop="checkPass">
    <el-input type="password" v-model="loginForm.password" auto-complete="off" 
	placeholder="密码" style="width:100%"
                @keyup.enter.native="submitClick"></el-input>
    </el-form-item> <!--按回车键执行-->
    <el-checkbox class="login_remember" v-model="checked" 
	  label-position="left" >记住密码</el-checkbox>
    <br><br><br>
	<el-form-item style="width: 100%">
      <el-button type="primary" @click.native.prevent="submitClick" 
	  style="width: 100%">登录</el-button>
    </el-form-item>
	<!--
	<el-form-item style="width: 100%">
	  <el-button type="primary" @click.native.prevent="openRegDialog" 
	  style="width: 100%">注册</el-button>
	</el-form-item>
	-->
	<!--
		1、在封装好的组件上使用，所以要加上.native才能click。
		2、prevent是用来阻止默认的事件。就相当于…event.preventDefault()，
		父组件想在子组件上监听自己的click的话，需要加上native修饰符。
	-->
  </el-form>
  
  <!--注册对话框 开始-->
  <el-dialog v-model="regVisible" title="注册">
  	<el-form>
  		<el-row>
  			<el-col :span="11" >
  				<el-form-item label="登录账号" >
  					<el-input v-model="addDept.deptno" autocomplete="off" 
  					type="number" size="small"/>
  				</el-form-item>
  			</el-col>	
  			<el-col :span="11">
  				<el-form-item label="登录密码" >
  					<el-input v-model="addDept.dname" autocomplete="off"  size="small"/>
  				</el-form-item>
  			</el-col>
  		</el-row>
  		<el-row>
  			<el-col :span="11">
  				<el-form-item label="真实姓名" >
  						<el-input v-model="addDept.locid" autocomplete="off" 
  						type="number" size="small"/>
  				</el-form-item>
			</el-col>
  		</el-row>
  	</el-form>
  	<template #footer>
  	    <span class="dialog-footer">
  	        <el-button type="primary" @click="addNewDept()" size="small">保存</el-button>
  			<el-button @click="regVisible = false" size="small">取消</el-button>
  	    </span>
  	</template>
  </el-dialog>
  <!--注册对话框 结束--> 
</template>

<!--javaScript代码部分-->
<script>
  import qs from 'qs'; //qs字符串工具类==键值对形式
  import axios from 'axios'; //使用AJAX工具类
  import { ElMessage } from 'element-plus'; //使用element组件
  export default{
    mounted: function () { //mounted==DOM挂载完毕
      this.init();
    },
    methods: {
      init() {
        var  userName =  localStorage.getItem("userName");
        var  password =  localStorage.getItem("password");
        var  save =  localStorage.getItem("isSave");
        //调试用  信息框
        //this.$alert('aa--->'+ c , '信息提示');
		//如果记住登录信息为真
        if(save == "true") {
            //设置复选框为选中
            this.checked = true;
            //保留上次的登录信息
            this.loginForm.username = userName;
            this.loginForm.password = password;
        } else {
            //不留上次的登录信息
            this.loginForm.username = "无";//"0" "无"
            this.loginForm.password = "";//" "
        }
      },
      //单击登录按钮事件
      submitClick() {
		//在不同的方法里,this有可能代表不同的对象,希望_this代表最初的对象
        let _this = this;
        if (_this.loginForm.username == null || _this.loginForm.username.length == 0
            || _this.loginForm.password == null || _this.loginForm.password.length == 0) {
            ElMessage({
		      message: '用户名和密码不能为空!',
		      type: 'info',
		      duration: 1000, //停留1秒钟
		      showClose: true //可手动关闭  showClose  show-close
		    })
            return;
        }
		//后端已经设置跨域访问了，前端就不用再设置了
	    let str=qs.stringify(_this.loginForm); //username=admin&password=admin123
		let url = "http://localhost:7070/newMenu/login?"+str;
		//alert("url="+url); 
		//按用户名和密码查询后端服务器
        //axios.post(url,str).then(resp=> {
		axios.get(url).then(resp=> {
		    var obj = resp.data;  //接收后端返回的数据
			console.log("obj="+obj)//V
			if (obj == null || obj.length == 0){
				_this.$alert('用户名 密码 不存在或错误!', '登录失败!');
				return;
			}
			let json_str = JSON.stringify(obj);
			console.log("json_str="+json_str)//V
			//把JSON字符串转换为JSON对象
			let new_user = JSON.parse(json_str);
		    //我们设置一个名为Flag，值为isLogin的字段，作用是如果Flag有值且为isLogin的时候，
			//证明用户已经登录了。
			//把登录成功的信息记录在sessionStorage里
			sessionStorage.setItem("Flag", "isLogin");
			//alert("new_user.realName="+new_user.realName);
		    sessionStorage.setItem("name", new_user.real_name);//json.realName
			sessionStorage.setItem("RoleID", new_user.role_id);//json.useType
			sessionStorage.setItem("id", new_user.id);//json.id
			if(_this.checked == true) {
				//把登录成功的信息记录在localStorage里
				localStorage.setItem("userName", _this.loginForm.username);
				localStorage.setItem("password", _this.loginForm.password);
				localStorage.setItem("isSave", true);
			}else{
				localStorage.setItem("isSave", false);
			}
			//登录成功后跳转到指定页面
			_this.$router.replace({path: '/home'});
		});
      },
	  //打开注册对话框
	  openRegDialog( ){
	  	var _this = this;
	  	_this.regVisible = true;
	  },
    },
	//数据区
	data() {
      return {
        checked: false,
        loginForm: {
          username: '',
          password: '',
        },
        loading: false,
		regVisible: false,
		addDept:{},
      }
    }
  }
</script>
<!--css样式表部分-->
<style>
.login-container {
    border-radius: 15px;
    background-clip: padding-box;
    margin: 90px auto;
    width: 350px;
    padding: 35px 35px 15px 35px;
    background: #fff;
    border: 1px solid #eaeaea;
    box-shadow: 0 0 25px #cac6c6;
	background: url("../assets/系统登录.png") repeat top center;
}
.login_title {
    margin: 0px auto 40px auto;
    text-align: center;
    /* color: #505458;*/
	color: white;
}
.login_remember {
    margin: 0px 0px 35px 0px;
    text-align: left;
	color: white;
}
.c1{
		/* 底部  no-repeat */
		background: url("../assets/bg_point.gif") repeat top center;
	}
</style>
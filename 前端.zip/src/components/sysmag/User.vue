<!-- 
  @Description: 用户管理前端页面
  @author: 孙勤学
  @date: 2025/9/11
-->
<template>
	<!--第一行查询输入框和按钮 开始-->
	<el-row>
		<el-col :span="6">
	        <el-input
	            placeholder="请输入用户名或真实姓名"  size="small"
	            v-model="UserName" style="width: 200px;">
	        </el-input>
	    </el-col>
	    <el-col :span="3">
	        <el-button @click="searchClick()" size="small">查询用户</el-button>
	    </el-col>
	    <el-col :span="3">
	        <el-button @click="openInsertDialog()" size="small">新增用户</el-button><br/>
	    </el-col>
		<el-col :span="3">
		    <el-button @click="datdel()" :disabled="this.selItems.length==0" size="small">
				批量删除</el-button><br/>
		</el-col>
	</el-row>
	<!-- 第一行查询输入框和按钮 结束-->
	
	<!-- 第二行数据表格 开始   opacity:0.5; width: 80%-->
	<el-table :data="userData"
	@selection-change="handleSelectionChange"  :cell-class-name="cellClassFn">
		<!--表格第1列 复选框-->
		<el-table-column
		  type="selection"
		  width="65" align="left" style="background-color: #333;">
		</el-table-column>
		<el-table-column prop="id" label="id" width="150" />
	    <el-table-column prop="user_name" label="用户名" width="150" />
		<el-table-column prop="user_password" label="密码" width="150" />
		<el-table-column prop="real_name" label="真实姓名" width="150" />
		<el-table-column prop="role_id" label="用户类型" width="150" >
			<template #default="scope">
			   {{ showzhuangtai(scope.row.role_id) }}
			</template>
	    </el-table-column>
		<el-table-column label="编辑" width="280">
			<template #default="scope">
				<!-- <el-icon><Sugar /></el-icon> -->
				<div style="background-color: transparent">
					<el-button size="small" @click="openUpdateDialog(scope.$index, scope.row)">					   		
						<el-icon><Edit /></el-icon>
					</el-button>
					<el-button size="small" @click="deleteRow(scope.$index,scope.row)">
						<el-icon><Delete /></el-icon>
					</el-button>
				</div>
			</template>
		</el-table-column>	
	</el-table>
	<!-- 第二行数据表格 结束-->
	<!-- totalRow totalCount v-show="this.deptData.length>0" -->
	<!--第三行分页组件 开始-->
	<el-col :span="5">
	    <el-pagination
		    small
	        background
	        :page-size="pageSize" :current-page.sync="currentPage"
	        layout="prev, pager, next" 
			:total="totalCount" @current-change="currentChange" v-show="this.totalCount>0" >
	    </el-pagination>
	</el-col>
	<!--第三行分页组件 结束-->
	
	<!--新增用户对话框 开始-->
	<el-dialog v-model="insertVisible" title="新增用户">
		<el-form>
			<el-row>
				<el-col :span="11">
					<el-form-item label="用户&emsp;名" >
						<el-input v-model="addUser.user_name" autocomplete="off"  size="small"/>
					</el-form-item>
				</el-col>
				<el-col :span="11">
					<el-form-item label="密&emsp;&emsp;码" >
							<el-input v-model="addUser.user_password" autocomplete="off" 
							 size="small" type="password"/>
					</el-form-item>
				</el-col>
			</el-row>
			<el-row>
				<el-col :span="11">
					<el-form-item label="真实姓名" >
						<el-input v-model="addUser.real_name" autocomplete="off" 
						 size="small"/>
					</el-form-item>
				</el-col>
				<el-col :span="11">
					<el-form-item label="用户类型" >
						<el-radio-group v-model="radio" class="ml-4">
							<el-radio size="small" @click="aaa = true;addUser.role_id=2;"  v-model="addUser.role_id" label="选项1">组织架构管理员</el-radio>
							<el-radio size="small" @click="bbb = true;addUser.role_id=3;"  v-model="addUser.role_id" label="选项2">考勤记录管理员</el-radio>
							<el-radio size="small" @click="ccc = true;addUser.role_id=5;"  v-model="addUser.role_id" label="选项3">请假管理员</el-radio>
						</el-radio-group>
					</el-form-item>
				</el-col>
			</el-row>
			<!-- <el-row v-if="aaa">
				<el-col :span="11">
					<el-form-item label="工厂名称" >
						<el-input v-model="factoryName" autocomplete="off"  size="small"/>
					</el-form-item>
				</el-col>
				<el-col :span="11">
					<el-form-item label="工厂简介" >
							<el-input v-model="factoryProfile" autocomplete="off" 
							 size="small"/>
					</el-form-item>
				</el-col>
			</el-row> -->
		</el-form>
		<template #footer>
		    <span class="dialog-footer">
		        <el-button type="primary" @click="addNewUser()" size="small">保存</el-button>
				<el-button @click="insertVisible = false" size="small">取消</el-button>
		    </span>
		</template>
	</el-dialog>
	<!--新增用户对话框 结束--> 
		 
	<!--修改用户对话框 开始-->
	<el-dialog v-model="updateVisible" title="修改用户">
		<el-form>
			<el-row>
				<el-col :span="11">
					<el-form-item label="用户&emsp;名" >
						<el-input v-model="updateUser.user_name" autocomplete="off"  size="small"/>
					</el-form-item>
				</el-col>
				<el-col :span="11">
					<el-form-item label="密&emsp;&emsp;&emsp;码" >
							<el-input v-model="updateUser.user_password" autocomplete="off" 
							 size="small"/>
					</el-form-item>
				</el-col>
			</el-row>
			<el-row>
				<el-col :span="11">
					<el-form-item label="真实姓名" >
							<el-input v-model="updateUser.real_name" autocomplete="off" 
							 size="small"/>
					</el-form-item>
				</el-col>
				<el-col :span="11">
					<el-form-item label="用户类型id" >
							<el-input v-model="updateUser.role_id" autocomplete="off" 
							 type="number" size="small" readonly/>
					</el-form-item>
				</el-col>
			</el-row>
		</el-form>
		<template #footer>
			<span class="dialog-footer">
				<el-button type="primary" @click="modifyUser()" size="small">保存</el-button>
				<el-button @click="updateVisible = false" size="small">取消</el-button>
			</span>
		</template>
	</el-dialog>
	<!--更新用户对话框 结束-->
</template>

<!--javaScript代码部分-->
<script>
	import qs from 'qs';        //处理字符串的工具类
	import axios from 'axios';  //异步访问后端的工具类
	import { ElMessage } from 'element-plus'; //element信息框工具类
	
	export default {
		//vue的方法区
		methods:{
			    //设置表格背景色
			    cellClassFn({row,column,rowIndex,columnIndex}){
				   return 'cc';
			    },
	            //查询按钮执行的方法
				searchClick(){
				    this.currentPage=1;
				    this.getData(this.currentPage, this.pageSize);
				},
				//查询方法==获取后端用户数据 
				getData(page, count){
					//在不同的方法里,this有可能代表不同的对象,希望_this代表最初的对象
					let _this=this;
					let url = "http://localhost:7070/newUser/listUser?pageNum=" + page 
					+ "&maxPageNum=" + count + "&keywords=" + _this.UserName;
					//获取用户数据 后端设置跨域访问了，前端不用设置了
					axios.get(url).then(resp=> {  //箭头函数
						_this.userData = resp.data.list;
						_this.totalCount = resp.data.totalRow;
						console.log(_this.userData);
					});
				},
				//刷新方法
				refresh() {
					//在不同的方法里,this有可能代表不同的对象,希望_this代表最初的对象
				    let _this = this;
				    _this.getData(this.currentPage, this.pageSize);
				},
				//翻页方法
				currentChange(currPage){
				    this.currentPage = currPage;
				    this.getData(currPage, this.pageSize);
				},
				//激活批量删除按钮
				handleSelectionChange(val) {
				    this.selItems = val;
				},
				//打开新增对话框
				openInsertDialog() {
					//在不同的方法里,this有可能代表不同的对象,希望_this代表最初的对象
					let _this = this;
					_this.insertVisible = true;
					_this.aaa=false;
					_this.radio='选项1';//默认选中
					_this.addUser.role_id=2;
				},
				//添加用户的方法
				addNewUser(){
					//代码片段里this有可能代表不同的对象,希望_this代表最初的对象
					var _this = this;
				    if ( 
				       _this.addUser.user_name == null || _this.addUser.user_name.length == 0
					  || _this.addUser.user_password == null || _this.addUser.user_password.length == 0
					  || _this.addUser.real_name == null || _this.addUser.real_name.length == 0 ) {
				        ElMessage({
					       message: '3数据不能为空!',
					       type: 'info',
					  	   duration: 1000, //停留1秒钟
					  	   //showClose: true //可手动关闭
					    })
				    }
				    else {
					    let str=qs.stringify(_this.addUser);//处理字符串的工具类  
						let url = "http://localhost:7070/newUser/addUser2?"+str;
						//axios.post(url,str).then(resp=> {
						axios.get(url).then(resp=> {
						if (resp.status == 200) {
							var json = resp.data;
							//alert("json="+json);
							if(json !='0') {
								_this.e_id = json;
								ElMessage({
								    message: '用户添加成功',
								    type: 'success', //类型
									duration: 1000,  //停留1秒钟
								})
								//满足条件插入数据
								if (_this.aaa == true) {
									//let str="factoryName="+_this.factoryName+"&factoryProfile="+ _this.factoryProfile+"&factoryStatus=1&userId="+ _this.e_id;
									let str="factory_name="+_this.factoryName+"&factory_profile="+ _this.factoryProfile+"&factory_status=1&user_id="+ _this.e_id;
									console.log(str);
									let url = "http://localhost:7070/newFactory/addFactory?"+str;
									//axios.post(url,str).then(resp=> {
									axios.get(url).then(resp=> {
								    if (resp.status == 200) {
										var json2 = resp.data;
										//alert("json="+json);
										if(json2=='1') {
											ElMessage({
												message: '工厂添加成功',
												type: 'success', //类型
												duration: 1000,  //停留1秒钟
											})
										} else {
											ElMessage({
												message: '工厂添加失败',
												type: 'error',  //类型
												duration: 3000, //停留3秒钟
												showClose: true //可手动关闭
											})
										}
										_this.factoryName = '';
										_this.factoryProfile = '';
								}
							})  
						    } 
							} else {
								ElMessage({
								    message: '用户添加失败',
								    type: 'error',  //类型
									duration: 3000, //停留3秒钟
									showClose: true //可手动关闭
								})
							}
							_this.addUser.user_name = '';
							_this.addUser.user_password = '';
							_this.addUser.real_name = '';
							_this.refresh();
				        }
				    }, resp=> {
				        if (resp.response.status == 403) {
							ElMessage({
								 message: '资源不可用',
								 type: 'error',
								 duration: 3000, //停留3秒钟
								 showClose: true //可手动关闭
							})
						}
				    });
				  }
				},
				//打开修改对话框
				openUpdateDialog(rIndex, row){
					var _this = this;
					_this.updateVisible = true
				    _this.updateUser.id=row.id;
					_this.updateUser.user_name=row.user_name;
					_this.updateUser.user_password=row.user_password;
					_this.updateUser.real_name=row.real_name;
					_this.updateUser.role_id=row.role_id;
				},
				//修改用户的方法
				modifyUser() {
				    //在不同的方法里,this有可能代表不同的对象,希望_this代表最初的对象
				    let _this = this;
				    if (_this.updateUser.id == null || 
					      _this.updateUser.id.length == 0
				       || _this.updateUser.user_name == null || 
					      _this.updateUser.user_name.length == 0
				       || _this.updateUser.user_password == null || 
					      _this.updateUser.user_password.length == 0
					   || _this.updateUser.real_name == null ||
						  _this.updateUser.real_name.length == 0
					   || _this.updateUser.role_id == null ||
					      _this.updateUser.role_id.length == 0) {
						ElMessage({
						   message: '3数据不能为空!',
						   type: 'info',
						   duration: 3000, //停留3秒钟
						   showClose: true //可手动关闭
						})
				    }
				  else {
				   let str=qs.stringify(_this.updateUser);
				   let url = "http://localhost:7070/newUser/updateUser";
				   axios.post(url, str).then(resp=> {   
						var json = resp.data;
				        //alert("json="+json);
						if(json=='1') {
							ElMessage({
							    message: '修改成功',
							    type: 'success', //类型
								duration: 1000,  //停留1秒钟
							})
							_this.refresh();
						} else {
							ElMessage({
							    message: '修改失败',
							    type: 'error',  //类型
								duration: 3000, //停留3秒钟
								showClose: true //可手动关闭
							})
						}
				    }, resp=> {
				        if (resp.response.status == 403) {
				            ElMessage({
						      message: '资源不可用',
						      type: 'error',
						  	  duration: 3000, //停留3秒钟
						  	  showClose: true //可手动关闭
						  })
				        }
				    });
				    _this.updateUser.id = '';
				    _this.updateUser.user_name = '';
				    _this.updateUser.user_password= '';
					_this.updateUser.real_name = '';
					_this.updateUser.role_id = '';
				    _this.updateVisible = false;
					_this.drawer = false;
				   }
				},
				//删除按钮执行的方法
				deleteRow(rIndex,row) {
					let _this = this;
					_this.$confirm('确认删除 "' + row.real_name + '" ?', '提示', {
					  confirmButtonText: '确定',
					  cancelButtonText: '取消',
					  type: 'warning'
					}).then(() => {
					  _this.deleteUser(row.id);
					  //删除数组中的数据
					  _this.userData.splice(rIndex,1);
					}).catch(() => {
					   //取消
					});
				},
				//删除用户==调用后端
				deleteUser(ids) {
				    let _this = this;
				    let str = "id=" + ids;
					let url = "http://localhost:7070/newUser/deleteUser";
					axios.post(url,str).then(resp=> {
					let json = resp.data;
					if(json=='1') {
						ElMessage({
						    message: '删除成功',
						    type: 'success', //停留1秒钟
							duration: 1000,
						})
					} else {
						ElMessage({
						    message: '删除失败',
						    type: 'error',
							duration: 3000, //停留3秒钟
							showClose: true //可手动关闭
						})
					}
				    _this.refresh();
				  }, resp=> {
				    _this.loading = false;
				    if (resp.response.status == 403) {
				      ElMessage({
				          message: '资源不可用',
				          type: 'error',
				      	duration: 3000, //停留3秒钟
				      	showClose: true //可手动关闭
				      })
				    } else if (resp.response.status == 500) {
				      ElMessage({
				          message: '服务器端代码错误',
				          type: 'error',
				      	  duration: 3000, //停留3秒钟
				      	  showClose: true //可手动关闭
				      })
				    }
				  })
				},
				datdel() { //批量删除用户
					//alert("datdel()");
					let _this = this;
					_this.$confirm('确认删除这 ' + _this.selItems.length + ' 条数据?'
					, '提示', {
					  type: 'warning',
					  confirmButtonText: '确定',
					  cancelButtonText: '取消'
					}).then(()=> {
					  let selItems = _this.selItems;
					  let ids = '';
					  for (let i = 0; i < selItems.length; i++) {
					    ids += selItems[i].id + ","; //3,6,10    ,
					  }
					  //alert("ids="+ids);
					  _this.deleteUser(ids.substring(0, ids.length - 1));
					  _this.refresh();
					}).catch(() => {
					  //取消
					});
				},
				//状态方法
				showzhuangtai(a){
					if(a=='1'){
					  return '系统管理员';
					}
					else if(a=='2'){
					  return '组织架构管理员';
					}else if(a=='3'){
					  return '考勤记录管理员';
					}else{
						return '请假管理员'
					}
				},
		},
		//vue的数据区
		data() {
				return {
					//翻页相关 {
					currentPage: 1,
					pageSize: 5,
					totalCount: '',
					//翻页相关 }
					selItems: [], //复选框-批量删除用
					UserName:'',
					userData:[],  //接收服务器传来的用户数据
					insertVisible: false, //用于新增对话框的显示和隐藏
					updateVisible: false, //用于更新对话框的显示和隐藏
					addUser:{},
					updateUser:{},
					radio: 0,
					aaa: false,
					factoryName:'', //测试加入部门后  利用新部门编号 插入员工  保留
					factoryProfile:''  ,//测试加入部门后  利用新部门编号 插入员工  保留
					e_id: 0,
				}
		},
    }
</script>

<!--css样式表部分-->
<style scoped>
	/* 设置表格背景色 */
	.el-table .cc {
		/* #CFFAF8 #42B983 #FAFFFF  transparent */
		background-color: #FAFFFF;
	}
	.el-button--text {
	  margin-right: 15px;
	}
	.el-select {
	  width: 300px;
	}
	.el-input {
	  width: 200px;
	}
	.dialog-footer button:first-child {
	  margin-right: 10px;
	}
	.el-pagination{
	  margin-left: 230px;
	}
	.el-table {
		width: 1095px;
	}
</style>
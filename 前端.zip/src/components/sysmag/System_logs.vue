<template>    
	<!--第一行查询输入框和按钮 开始-->
	<el-row>
		<el-col :span="6">
	        <el-input
	            placeholder="请输入操作人ID或操作类型"  size="small"
	            v-model="log_keywords" style="width: 200px;">
	        </el-input>
	    </el-col>
	    <el-col :span="3">
	        <el-button @click="searchClick()" size="small">查询系统日志</el-button>
	    </el-col>
	    <el-col :span="3">
	        <el-button @click="openInsertDialog()" size="small">新增系统日志</el-button><br/>
	    </el-col>
		<el-col :span="3">
		    <el-button @click="datdel()" :disabled="this.selItems.length==0" size="small">
				批量删除</el-button><br/>
		</el-col>
	</el-row>
	<!-- 第一行查询输入框和按钮 结束-->
	
	<!-- 第二行数据表格 开始 -->
	<el-table :data="logsData" 
	@selection-change="handleSelectionChange"  :cell-class-name="cellClassFn">
		<!--表格第1列 复选框-->
		<el-table-column
		  type="selection"
		  width="55" align="left" style="background-color: #333;">
		</el-table-column>    
		<el-table-column fixed prop="log_id" label="日志唯一ID" width="120" style="background-color: #333;"/>
	    <el-table-column fixed prop="user_id" label="操作人ID" width="120" />
		<el-table-column prop="action_type" label="操作类型" width="120" />
		<el-table-column prop="action_details" label="操作详情" width="220" />
		<el-table-column prop="ip_address" label="操作IP地址" width="150" />
		<el-table-column prop="created_time" label="操作时间" width="180" />
		<el-table-column fixed="right" label="编辑" width="280">
			<template #default="scope">
				<div style="background-color: transparent">
					<el-button type="info" size="small" @click="openUpdateDialog(scope.$index, scope.row)">					   		
						<el-icon><Edit /></el-icon>
					</el-button>
					<el-button type="danger" size="small" @click="deleteRow(scope.$index,scope.row)">
						<el-icon><Delete /></el-icon>
					</el-button>
					<el-button type="primary" circle size="small"  @click="openUpdateDialog02(scope.$index, scope.row)">
						<el-icon><View /></el-icon>
					</el-button>
				</div>
			</template>
		</el-table-column>	
	</el-table>
	<!-- 第二行数据表格 结束-->
	
	<!--第三行分页组件 开始-->
	<el-col :span="5">
	    <el-pagination
		    small
	        background
	        :page-size="pageSize" :current-page.sync="currentPage"
	        layout="prev, pager, next" 
			:total="totalCount" @current-change="currentChange" v-show="this.totalCount>0" >
	    </el-pagination>
	</el-col>
	<!--第三行分页组件 结束-->
	
	<!--新增系统日志对话框 开始-->
	<el-dialog v-model="insertVisible" title="新增系统日志">
		<el-form>
			<el-row>
				<el-col :span="11" >
					<el-form-item label="日志唯一ID" >
						<el-input v-model="addLogs.log_id" autocomplete="off" 
						type="number" size="small" />
					</el-form-item>
				</el-col>	
				<el-col :span="11">
					<el-form-item label="操作人ID" >
						<el-input v-model="addLogs.user_id" autocomplete="off" 
						type="number" size="small" />
					</el-form-item>
				</el-col>
			</el-row>
			<el-row>
				<el-col :span="11" >
					<el-form-item label="操作类型" >
						<el-input v-model="addLogs.action_type" autocomplete="off" size="small"/>
					</el-form-item>
				</el-col>	
				<el-col :span="11">
					<el-form-item label="操作IP地址" >
						<el-input v-model="addLogs.ip_address" autocomplete="off" size="small"/>
					</el-form-item>
				</el-col>
			</el-row>
			<el-row>
				<el-col :span="22" >
					<el-form-item label="操作详情" >
						<el-input v-model="addLogs.action_details" autocomplete="off" 
						type="textarea" rows="3" size="small"/>
					</el-form-item>
				</el-col>
			</el-row>
			<el-row>
				<el-col :span="11" >
					<el-form-item label="操作时间" >
						<el-input v-model="addLogs.created_time" autocomplete="off"
						type="datetime-local" size="small"/>
					</el-form-item>
				</el-col>
			</el-row>
		</el-form>
		<template #footer>
		    <span class="dialog-footer">
		        <el-button type="primary" @click="addNewLogs()" size="small">保存</el-button>
				<el-button @click="insertVisible = false" size="small">取消</el-button>
		    </span>
		</template>
	</el-dialog>
	<!--新增系统日志对话框 结束-->
		 
	<!--修改系统日志对话框 开始-->
	<el-dialog v-model="updateVisible" title="修改系统日志">
		<el-form>
			<el-row>
				<el-col :span="11" >
					<el-form-item label="日志唯一ID" >
						<el-input v-model="updateLogs.log_id" autocomplete="off" 
						type="number" size="small" readonly/>
					</el-form-item>
				</el-col>	
				<el-col :span="11">
					<el-form-item label="操作人ID" >
						<el-input v-model="updateLogs.user_id" autocomplete="off" 
						type="number" size="small" />
					</el-form-item>
				</el-col>
			</el-row>
			<el-row>
				<el-col :span="11" >
					<el-form-item label="操作类型" >
						<el-input v-model="updateLogs.action_type" autocomplete="off" size="small"/>
					</el-form-item>
				</el-col>	
				<el-col :span="11">
					<el-form-item label="操作IP地址" >
						<el-input v-model="updateLogs.ip_address" autocomplete="off" size="small"/>
					</el-form-item>
				</el-col>
			</el-row>
			<el-row>
				<el-col :span="22" >
					<el-form-item label="操作详情" >
						<el-input v-model="updateLogs.action_details" autocomplete="off" 
						type="textarea" rows="3" size="small"/>
					</el-form-item>
				</el-col>
			</el-row>
			<el-row>
				<el-col :span="11" >
					<el-form-item label="操作时间" >
						<el-input v-model="updateLogs.created_time" autocomplete="off"
						type="datetime-local" size="small"/>
					</el-form-item>
				</el-col>
			</el-row>
		</el-form>
		<template #footer>
			<span class="dialog-footer">
				<el-button type="primary" @click="modifyLogs()" size="small">保存</el-button>
				<el-button @click="updateVisible = false" size="small">取消</el-button>
			</span>
		</template>
	</el-dialog>
	<!--修改系统日志对话框 结束-->
	
	<!--查看系统日志详情对话框 开始-->
	<el-dialog v-model="updateVisible02" title="查看系统日志详情">
		<el-form>
			<el-row>
				<el-col :span="11" >
					<el-form-item label="日志唯一ID" >
						<el-input v-model="updateLogs02.log_id" autocomplete="off" 
						type="number" size="small" readonly/>
					</el-form-item>
				</el-col>	
				<el-col :span="11">
					<el-form-item label="操作人ID" >
						<el-input v-model="updateLogs02.user_id" autocomplete="off"  size="small" readonly/>
					</el-form-item>
				</el-col>
			</el-row>
			<el-row>
				<el-col :span="11" >
					<el-form-item label="操作类型" >
						<el-input v-model="updateLogs02.action_type" autocomplete="off" size="small" readonly/>
					</el-form-item>
				</el-col>	
				<el-col :span="11">
					<el-form-item label="操作IP地址" >
						<el-input v-model="updateLogs02.ip_address" autocomplete="off" size="small" readonly/>
					</el-form-item>
				</el-col>
			</el-row>
			<el-row>
				<el-col :span="22" >
					<el-form-item label="操作详情" >
						<el-input v-model="updateLogs02.action_details" autocomplete="off" 
						type="textarea" rows="3" size="small" readonly/>
					</el-form-item>
				</el-col>
			</el-row>
			<el-row>
				<el-col :span="11" >
					<el-form-item label="操作时间" >
						<el-input v-model="updateLogs02.created_time" autocomplete="off" size="small" readonly/>
					</el-form-item>
				</el-col>
			</el-row>
		</el-form>
		<template #footer>
			<span class="dialog-footer">
				<el-button type="primary" @click="updateVisible02 = false" size="small">取消</el-button>
			</span>
		</template>
	</el-dialog>
	<!--查看系统日志详情对话框 结束-->
</template>

<!--javaScript代码部分-->
<script>
	import qs from 'qs';        //处理字符串的工具类
	import axios from 'axios';  //异步访问后端的工具类
	import { ElMessage } from 'element-plus'; //element信息框工具类
	
	export default {
		//vue的方法区
		methods:{
			    //设置表格背景色
			    cellClassFn({row,column,rowIndex,columnIndex}){
				   return 'cc';
			    },
	            //查询按钮执行的方法
				searchClick(){
				    this.currentPage=1;
				    this.getData(this.currentPage, this.pageSize);
				},
				//查询方法==获取后端系统日志数据 
				getData(page, count){
					let _this=this;
					// 接口路径严格匹配表名System_logs
					let url = "http://localhost:7070/newSystem_logs/listSystem_logs?pageNum=" + page 
					+ "&maxPageNum=" + count + "&keywords=" + _this.log_keywords;
					axios.get(url).then(resp=> {  
						_this.logsData = resp.data.list;
						_this.totalCount = resp.data.totalRow;
						console.log(_this.logsData);
					});
				},
				//刷新方法
				refresh() {
				    let _this = this;
				    _this.getData(this.currentPage, this.pageSize);
				},
				//翻页方法
				currentChange(currPage){
				    this.currentPage = currPage;
				    this.getData(currPage, this.pageSize);
				},
				//激活批量删除按钮
				handleSelectionChange(val) {
				    this.selItems = val;
				},
				//打开新增对话框
				openInsertDialog() {
					let _this = this;
					_this.insertVisible = true;
					// 接口路径严格匹配表名System_logs
					let url = "http://localhost:7070/newSystem_logs/listSystem_logs?pageNum=1&maxPageNum=100&keywords=";
					axios.get(url).then(resp=> {
						_this.logsArr = resp.data.list;
					});
				},
				//添加系统日志的方法
				addNewLogs(){
					var _this = this;
				    // 验证所有非空字段（匹配System_logs表非空规则）
				    if (!_this.addLogs.log_id || !_this.addLogs.user_id 
					|| !_this.addLogs.action_type || !_this.addLogs.action_details 
					|| !_this.addLogs.ip_address || !_this.addLogs.created_time) {
				        ElMessage({
					       message: '数据不能为空!',
					       type: 'info',
					  	   duration: 1000
					    })
				    }
				    else {
					    let str=qs.stringify(_this.addLogs);  
						// 接口路径严格匹配表名System_logs
						let url = "http://localhost:7070/newSystem_logs/addSystem_logs?"+str;
						axios.get(url).then(resp=> {
						if (resp.status == 200) {
							var json = resp.data;
							if(json=='1') {
								ElMessage({
								    message: '添加成功',
								    type: 'success',
									duration: 1000
								})
							} else {
								ElMessage({
								    message: '添加失败',
								    type: 'error',
									duration: 3000,
									showClose: true
								})
							}
							// 清空表单
							_this.addLogs = {};
							_this.refresh();
				        }
				    }, resp=> {
				        if (resp.response.status == 403) {
							ElMessage({
								 message: '资源不可用',
								 type: 'error',
								 duration: 3000,
								 showClose: true
							})
						}
				    });
				  }
				},
				//打开修改对话框
				openUpdateDialog(rIndex, row){
					var _this = this;
					_this.updateVisible = true;
					
					// 接口路径严格匹配表名System_logs
					let url = "http://localhost:7070/newSystem_logs/listSystem_logs?pageNum=1&maxPageNum=100&keywords=";
					axios.get(url).then(resp=> {
						_this.logsArr = resp.data.list;
					});
					
				    // 回显系统日志字段
				    _this.updateLogs.log_id = row.log_id;
					_this.updateLogs.user_id = row.user_id;
					_this.updateLogs.action_type = row.action_type;
					_this.updateLogs.action_details = row.action_details;
					_this.updateLogs.ip_address = row.ip_address;
					_this.updateLogs.created_time = row.created_time;
				},
				
				//打开系统日志详情对话框
				openUpdateDialog02(rIndex, row){
					var _this = this;
					_this.updateVisible02 = true;
				    // 回显详情字段
				    _this.updateLogs02.log_id = row.log_id;
					_this.updateLogs02.user_id = row.user_id;
					_this.updateLogs02.action_type = row.action_type;
					_this.updateLogs02.action_details = row.action_details;
					_this.updateLogs02.ip_address = row.ip_address;
					_this.updateLogs02.created_time = row.created_time;
				},
				
				//修改系统日志的方法
				modifyLogs() {
				    let _this = this;
				    // 验证所有非空字段
				    if (!_this.updateLogs.log_id || !_this.updateLogs.user_id 
					|| !_this.updateLogs.action_type || !_this.updateLogs.action_details 
					|| !_this.updateLogs.ip_address || !_this.updateLogs.created_time) {
						ElMessage({
						   message: '数据不能为空!',
						   type: 'info',
						   duration: 3000,
						   showClose: true
						})
				    }
				  else {
				   let str=qs.stringify(_this.updateLogs);
				   // 接口路径严格匹配表名System_logs
				   let url = "http://localhost:7070/newSystem_logs/updateSystem_logs";
				   axios.post(url, str).then(resp=> {   
						var json = resp.data;
						if(json=='1') {
							ElMessage({
							    message: '修改成功',
							    type: 'success',
								duration: 1000
							})
							 _this.refresh();
						} else {
							ElMessage({
							    message: '修改失败',
							    type: 'error',
								duration: 3000,
								showClose: true
							})
						}
				    }, resp=> {
				        if (resp.response.status == 403) {
				            ElMessage({
						      message: '资源不可用',
						      type: 'error',
						  	  duration: 3000,
						  	  showClose: true
						  })
				        }
				    });
					// 清空表单
					_this.updateLogs = {};
				    _this.updateVisible = false;
					_this.drawer = false;
				   }
				},
				//删除按钮执行的方法
				deleteRow(rIndex,row) {
					let _this = this;
					_this.$confirm('确认删除日志 "' + row.log_id + '" ?', '提示', {
					  confirmButtonText: '确定',
					  cancelButtonText: '取消',
					  type: 'warning'
					}).then(() => {
					  _this.deleteSystemLog(row.log_id);
					  //删除数组中的数据
					  _this.logsData.splice(rIndex,1);
					}).catch(() => {
					   //取消
					});
				},
				//删除系统日志==调用后端
				deleteSystemLog(ids) {
				    let _this = this;
				    let str = "log_id=" + ids;
					// 接口路径严格匹配表名System_logs
					let url = "http://localhost:7070/newSystem_logs/deleteSystem_logs";
					axios.post(url,str).then(resp=> {
					let json = resp.data;
					if(json=='1') {
						ElMessage({
						    message: '删除成功',
						    type: 'success',
							duration: 1000,
						})
					} else {
						ElMessage({
						    message: '删除失败',
						    type: 'error',
							duration: 3000,
							showClose: true
						})
					}
				    _this.refresh();
				  }, resp=> {
				    _this.loading = false;
				    if (resp.response.status == 403) {
				      ElMessage({
				          message: '资源不可用',
				          type: 'error',
				      	duration: 3000,
				      	showClose: true
				      })
				    } else if (resp.response.status == 500) {
				      ElMessage({
				          message: '服务器端代码错误',
				          type: 'error',
				      	  duration: 3000,
				      	  showClose: true
				      })
				    }
				  })
				},
				//批量删除系统日志
				datdel() {
					let _this = this;
					_this.$confirm('确认删除这 ' + _this.selItems.length + ' 条日志数据?'
					, '提示', {
					  type: 'warning',
					  confirmButtonText: '确定',
					  cancelButtonText: '取消'
					}).then(()=> {
					  let selItems = _this.selItems;
					  let ids = '';
					  for (let i = 0; i < selItems.length; i++) {
					    ids += selItems[i].log_id + ",";
					  }
					  _this.deleteSystemLog(ids.substring(0, ids.length - 1));
					  _this.refresh();
					}).catch(() => {
					  //取消
					});
				},
		},
		//vue的数据区
		data() {
				return {
					//翻页相关
					currentPage: 1,
					pageSize: 5,
					totalCount: '',
					//批量删除用
					selItems: [],
					//查询关键词
					log_keywords:'',
					//接收服务器传来的日志数据
					logsData:[],
					//对话框显示隐藏控制
					insertVisible: false, 
					updateVisible: false, 
					updateVisible02: false,
					//新增日志表单数据
					addLogs:{},
					//修改日志表单数据
					updateLogs:{},
					//查看详情日志数据
					updateLogs02:{},
					//接收服务器传来的日志列表数据
					logsArr:[],
				}
		},
    }
</script>

<!--css样式表部分-->
<style scoped>
	/* 设置表格背景色 */
	.el-table .cc {
		background-color: #FAFFFF;
	}
	.el-button--text {
	  margin-right: 15px;
	}
	.el-select {
	  width: 300px;
	}
	.el-input {
	  width: 200px;
	}
	.dialog-footer button:first-child {
	  margin-right: 10px;
	}
	.el-pagination{
		margin-left: 230px;
	}
	.el-table {
		width: 1020px;
	}
</style>

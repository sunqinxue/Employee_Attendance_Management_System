<!-- 
  @Description: 部门管理前端页面
  @author： 孙勤学
  @date：2025/9/17
-->
<template>    
    <!-- 第一行查询输入框和按钮 开始 -->
    <el-row>
        <el-col :span="6">
            <el-input
                placeholder="请输入部门编号或名称"  
                size="small"
                v-model="departmentName" 
                style="width: 200px;"
            >
            </el-input>
        </el-col>
        <el-col :span="3">
            <el-button @click="searchClick()" size="small">查询部门</el-button>
        </el-col>
        <el-col :span="3">
            <el-button @click="openInsertDialog()" size="small">新增部门</el-button><br/>
        </el-col>
        <el-col :span="3">
            <el-button 
                @click="datdel()" 
                :disabled="this.selItems.length === 0" 
                size="small"
            >
                批量删除
            </el-button><br/>
        </el-col>
    </el-row>
    <!-- 第一行查询输入框和按钮 结束 -->

    <!-- 第二行数据表格 开始 -->
    <el-table 
        :data="departmentsData" 
        @selection-change="handleSelectionChange"  
        :cell-class-name="cellClassFn"
    >
        <!-- 表格第1列 复选框 -->
        <el-table-column
            type="selection"
            width="55" 
            align="left" 
            style="background-color: #333;"
        >
        </el-table-column>    
        <el-table-column 
            fixed 
            prop="department_id" 
            label="部门编号" 
            width="120" 
            style="background-color: #333;"
        />
        <el-table-column 
            fixed 
            prop="department_name" 
            label="部门名称" 
            width="120" 
        />
        <el-table-column 
            prop="parent_id" 
            label="上级部门ID" 
            width="120" 
        />
        <el-table-column 
            prop="manager_id" 
            label="部门负责人ID" 
            width="120" 
        />
        <el-table-column 
            prop="created_time" 
            label="创建时间" 
            width="120" 
        />
        <el-table-column fixed="right" label="编辑" width="280">
            <template #default="scope">
                <div style="background-color: transparent">
                    <el-button 
                        type="info" 
                        size="small" 
                        @click="openUpdateDialog(scope.$index, scope.row)"
                    >					   
                        <el-icon><Edit /></el-icon>
                    </el-button>
                    <el-button 
                        type="danger" 
                        size="small" 
                        @click="deleteRow(scope.$index, scope.row)"
                    >
                        <el-icon><Delete /></el-icon>
                    </el-button>
                    <el-button 
                        type="primary" 
                        circle 
                        size="small"  
                        @click="openUpdateDialog02(scope.$index, scope.row)"
                    >
                        <el-icon><View /></el-icon>
                    </el-button>
                </div>
            </template>
        </el-table-column>	
    </el-table>
    <!-- 第二行数据表格 结束 -->

    <!-- 第三行分页组件 开始 -->
    <el-col :span="5">
        <el-pagination
            small
            background
            :page-size="pageSize" 
            :current-page.sync="currentPage"
            layout="prev, pager, next" 
            :total="totalCount" 
            @current-change="currentChange" 
            v-show="this.totalCount > 0"
        >
        </el-pagination>
    </el-col>
    <!-- 第三行分页组件 结束 -->

    <!-- 新增部门对话框 开始 -->
    <el-dialog v-model="insertVisible" title="新增部门">
        <el-form>
            <el-row>
                <el-col :span="11">
                    <el-form-item label="部门编号">
                        <el-input 
                            v-model="addDepartment.department_id" 
                            autocomplete="off" 
                            type="number" 
                            size="small" 
                        />
                    </el-form-item>
                </el-col>	
                <el-col :span="11">
                    <el-form-item label="部门名称">
                        <el-select 
                            placeholder="部门名称" 
                            size="small"
                            v-model="addDepartment.department_name"
                            clearable 
                            filterable 
                            style="width:200px"
                        >
                            <el-option 
                                v-for="item in departmentsArr"
                                :key="item.department_id"
                                :label="item.department_name"
                                :value="item.department_name"
                            >
                            </el-option>  
                        </el-select>
                    </el-form-item>
                </el-col>
            </el-row>
            <el-row>
                <el-col :span="11">
                    <el-form-item label="上级部门ID">
                        <el-input 
                            v-model="addDepartment.parent_id" 
                            autocomplete="off" 
                            type="number" 
                            size="small"
                        />
                    </el-form-item>
                </el-col>	
                <el-col :span="11">
                    <el-form-item label="部门负责人ID">
                        <el-input 
                            v-model="addDepartment.manager_id" 
                            autocomplete="off" 
                            type="number" 
                            size="small"
                        />
                    </el-form-item>
                </el-col>
            </el-row>
            <el-row>
                <el-col :span="22">
                    <el-form-item label="创建时间">
                        <el-input 
                            v-model="addDepartment.created_time" 
                            autocomplete="off"
                            type="date" 
                            size="small"
                        />
                    </el-form-item>
                </el-col>	
            </el-row>
        </el-form>
        <template #footer>
            <span class="dialog-footer">
                <el-button type="primary" @click="addNewDepartment()" size="small">保存</el-button>
                <el-button @click="insertVisible = false" size="small">取消</el-button>
            </span>
        </template>
    </el-dialog>
    <!-- 新增部门对话框 结束 -->

    <!-- 修改部门对话框 开始 -->
    <el-dialog v-model="updateVisible" title="修改部门">
        <el-form>
            <el-row>
                <el-col :span="11">
                    <el-form-item label="部门编号">
                        <el-input 
                            v-model="updateDepartment.department_id" 
                            autocomplete="off" 
                            type="number" 
                            size="small" 
                            readonly
                        />
                    </el-form-item>
                </el-col>	
                <el-col :span="11">
                    <el-form-item label="部门名称">
                        <el-select 
                            placeholder="部门名称" 
                            size="small"
                            v-model="updateDepartment.department_name"
                            clearable 
                            filterable 
                            style="width:200px"
                        >
                            <el-option 
                                v-for="item in departmentsArr"
                                :key="item.department_id"
                                :label="item.department_name"
                                :value="item.department_name"
                            >
                            </el-option>  
                        </el-select>
                    </el-form-item>
                </el-col>
            </el-row>
            <el-row>
                <el-col :span="11">
                    <el-form-item label="上级部门ID">
                        <el-input 
                            v-model="updateDepartment.parent_id" 
                            autocomplete="off" 
                            type="number" 
                            size="small"
                        />
                    </el-form-item>
                </el-col>	
                <el-col :span="11">
                    <el-form-item label="部门负责人ID">
                        <el-input 
                            v-model="updateDepartment.manager_id" 
                            autocomplete="off" 
                            type="number" 
                            size="small"
                        />
                    </el-form-item>
                </el-col>
            </el-row>
            <el-row>
                <el-col :span="22">
                    <el-form-item label="创建时间">
                        <el-input 
                            v-model="updateDepartment.created_time" 
                            autocomplete="off" 
                            size="small"
                        />
                    </el-form-item>
                </el-col>	
            </el-row>
        </el-form>
        <template #footer>
            <span class="dialog-footer">
                <el-button type="primary" @click="modifyDepartment()" size="small">保存</el-button>
                <el-button @click="updateVisible = false" size="small">取消</el-button>
            </span>
        </template>
    </el-dialog>
    <!-- 修改部门对话框 结束 -->

    <!-- 查看部门详情对话框 开始 -->
    <el-dialog v-model="updateVisible02" title="查看部门详情">
        <el-form>
            <el-row>
                <el-col :span="11">
                    <el-form-item label="部门编号">
                        <el-input 
                            v-model="updateDepartment02.department_id" 
                            autocomplete="off" 
                            type="number" 
                            size="small" 
                            readonly
                        />
                    </el-form-item>
                </el-col>	
                <el-col :span="11">
                    <el-form-item label="部门名称">
                        <el-input 
                            v-model="updateDepartment02.department_name" 
                            autocomplete="off"  
                            size="small" 
                            readonly
                        />
                    </el-form-item>
                </el-col>
            </el-row>
            <el-row>
                <el-col :span="11">
                    <el-form-item label="上级部门ID">
                        <el-input 
                            v-model="updateDepartment02.parent_id" 
                            autocomplete="off" 
                            size="small" 
                            readonly
                        />
                    </el-form-item>
                </el-col>	
                <el-col :span="11">
                    <el-form-item label="部门负责人ID">
                        <el-input 
                            v-model="updateDepartment02.manager_id" 
                            autocomplete="off" 
                            size="small" 
                            readonly
                        />
                    </el-form-item>
                </el-col>
            </el-row>
            <el-row>
                <el-col :span="22">
                    <el-form-item label="创建时间">
                        <el-input 
                            v-model="updateDepartment02.created_time" 
                            autocomplete="off" 
                            size="small" 
                            readonly
                        />
                    </el-form-item>
                </el-col>	
            </el-row>
        </el-form>
        <template #footer>
            <span class="dialog-footer">
                <el-button type="primary" @click="updateVisible02 = false" size="small">取消</el-button>
            </span>
        </template>
    </el-dialog>
    <!-- 查看部门详情对话框 结束 -->
</template>

<!-- JavaScript代码部分 -->
<script>
import qs from 'qs';                  // 处理字符串的工具类
import axios from 'axios';            // 异步访问后端的工具类
import { ElMessage } from 'element-plus'; // Element信息框工具类
import { Edit, Delete, View } from '@element-plus/icons-vue'; // 引入所需图标

export default {
    components: { Edit, Delete, View }, // 注册图标组件
    // Vue的方法区
    methods: {
        // 设置表格背景色
        cellClassFn({ row, column, rowIndex, columnIndex }) {
            return 'cc';
        },

        // 查询按钮执行的方法
        searchClick() {
            this.currentPage = 1;
            this.getData(this.currentPage, this.pageSize);
        },

        // 查询方法==获取后端部门数据 
        getData(page, count) {
            // 保存this上下文，避免箭头函数外this指向变更
            const _this = this;
            const url = `http://localhost:7070/departments/listDepartments?pageNum=${page}&maxPageNum=${count}&keywords=${_this.departmentName}`;
            
            // 调用后端接口获取部门数据
            axios.get(url).then(resp => {
                _this.departmentsData = resp.data.list;
                _this.totalCount = resp.data.totalRow;
                console.log(_this.departmentsData);
            });
        },

        // 刷新方法
        refresh() {
            const _this = this;
            _this.getData(this.currentPage, this.pageSize);
        },

        // 翻页方法
        currentChange(currPage) {
            this.currentPage = currPage;
            this.getData(currPage, this.pageSize);
        },

        // 激活批量删除按钮（监听表格选择事件）
        handleSelectionChange(val) {
            this.selItems = val;
        },

        // 打开新增对话框
        openInsertDialog() {
            const _this = this;
            _this.insertVisible = true;
            
            // 获取部门列表数据（用于下拉选择）
            const url = 'http://localhost:7070/departments/listDepartments?pageNum=1&maxPageNum=100&keywords=';
            axios.get(url).then(resp => {
                _this.departmentsArr = resp.data.list;
            });
        },

        // 添加部门的方法
        addNewDepartment() {
            const _this = this;
            // 表单校验：部门编号和名称不能为空
            if (!_this.addDepartment.department_id || !_this.addDepartment.department_name) {
                ElMessage({
                    message: '数据不能为空!',
                    type: 'info',
                    duration: 1000
                });
                return;
            }

            // 格式化表单数据
            const str = qs.stringify(_this.addDepartment);
            const url = `http://localhost:7070/departments/addDepartments?${str}`;

            // 调用新增接口
            axios.get(url).then(resp => {
                if (resp.status === 200) {
                    const json = resp.data;
                    if (json === '1') {
                        ElMessage({
                            message: '添加成功',
                            type: 'success',
                            duration: 1000
                        });
                    } else {
                        ElMessage({
                            message: '添加失败',
                            type: 'error',
                            duration: 3000,
                            showClose: true
                        });
                    }
                    // 重置表单 + 刷新数据
                    _this.addDepartment = {};
                    _this.refresh();
                }
            }).catch(resp => {
                if (resp.response?.status === 403) {
                    ElMessage({
                        message: '资源不可用',
                        type: 'error',
                        duration: 3000,
                        showClose: true
                    });
                }
            });
        },

        // 打开修改对话框
        openUpdateDialog(rIndex, row) {
            const _this = this;
            _this.updateVisible = true;

            // 获取部门列表数据（用于下拉选择）
            const url = 'http://localhost:7070/departments/listDepartments?pageNum=1&maxPageNum=100&keywords=';
            axios.get(url).then(resp => {
                _this.departmentsArr = resp.data.list;
            });

            // 回显当前行数据
            _this.updateDepartment = {
                department_id: row.department_id,
                department_name: row.department_name,
                parent_id: row.parent_id,
                manager_id: row.manager_id,
                created_time: row.created_time
            };
        },

        // 打开部门详情对话框
        openUpdateDialog02(rIndex, row) {
            const _this = this;
            _this.updateVisible02 = true;

            // 回显当前行数据（详情页只读）
            _this.updateDepartment02 = {
                department_id: row.department_id,
                department_name: row.department_name,
                parent_id: row.parent_id,
                manager_id: row.manager_id,
                created_time: row.created_time
            };
        },

        // 修改部门的方法
        modifyDepartment() {
            const _this = this;
            // 表单校验：部门编号和名称不能为空
            if (!_this.updateDepartment.department_id || !_this.updateDepartment.department_name) {
                ElMessage({
                    message: '数据不能为空!',
                    type: 'info',
                    duration: 3000,
                    showClose: true
                });
                return;
            }

            // 格式化表单数据
            const str = qs.stringify(_this.updateDepartment);
            const url = 'http://localhost:7070/departments/updateDepartments';

            // 调用修改接口
            axios.post(url, str).then(resp => {
                const json = resp.data;
                if (json === '1') {
                    ElMessage({
                        message: '修改成功',
                        type: 'success',
                        duration: 1000
                    });
                    _this.refresh();
                } else {
                    ElMessage({
                        message: '修改失败',
                        type: 'error',
                        duration: 3000,
                        showClose: true
                    });
                }
                // 重置表单 + 关闭对话框
                _this.updateDepartment = {};
                _this.updateVisible = false;
                _this.drawer = false;
            }).catch(resp => {
                if (resp.response?.status === 403) {
                    ElMessage({
                        message: '资源不可用',
                        type: 'error',
                        duration: 3000,
                        showClose: true
                    });
                }
            });
        },

        // 单行删除按钮执行的方法
        deleteRow(rIndex, row) {
            const _this = this;
            // 弹出确认对话框
            _this.$confirm(`确认删除 "${row.department_name}" ?`, '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(() => {
                // 调用删除接口
                _this.deleteDepartment(row.department_id);
                // 前端删除表格数据（优化体验）
                _this.departmentsData.splice(rIndex, 1);
            }).catch(() => {
                // 取消删除，不执行操作
            });
        },

        // 删除部门==调用后端接口
        deleteDepartment(ids) {
            const _this = this;
            const str = `department_id=${ids}`;
            const url = 'http://localhost:7070/departments/deleteDepartments';

            axios.post(url, str).then(resp => {
                const json = resp.data;
                if (json === '1') {
                    ElMessage({
                        message: '删除成功',
                        type: 'success',
                        duration: 1000
                    });
                } else {
                    ElMessage({
                        message: '删除失败',
                        type: 'error',
                        duration: 3000,
                        showClose: true
                    });
                }
                // 刷新数据
                _this.refresh();
            }).catch(resp => {
                _this.loading = false;
                if (resp.response?.status === 403) {
                    ElMessage({
                        message: '资源不可用',
                        type: 'error',
                        duration: 3000,
                        showClose: true
                    });
                } else if (resp.response?.status === 500) {
                    ElMessage({
                        message: '服务器端代码错误',
                        type: 'error',
                        duration: 3000,
                        showClose: true
                    });
                }
            });
        },

        // 批量删除部门
        datdel() {
            const _this = this;
            // 弹出确认对话框
            _this.$confirm(`确认删除这 ${_this.selItems.length} 条数据?`, '提示', {
                type: 'warning',
                confirmButtonText: '确定',
                cancelButtonText: '取消'
            }).then(() => {
                // 拼接选中的部门ID（逗号分隔）
                let ids = '';
                _this.selItems.forEach(item => {
                    ids += `${item.department_id},`;
                });
                // 去除最后一个逗号
                ids = ids.slice(0, -1);
                // 调用删除接口
                _this.deleteDepartment(ids);
                // 刷新数据
                _this.refresh();
            }).catch(() => {
                // 取消删除，不执行操作
            });
        }
    },

    // Vue的数据区
    data() {
        return {
            // 翻页相关配置
            currentPage: 1,
            pageSize: 5,
            totalCount: '',

            selItems: [], // 复选框选中的数据（批量删除用）
            departmentName: '', // 查询关键字（部门编号/名称）
            departmentsData: [], // 接收服务器传来的部门列表数据
            departmentsArr: [], // 部门下拉选择框数据

            // 对话框显示/隐藏控制
            insertVisible: false,  // 新增对话框
            updateVisible: false,  // 修改对话框
            updateVisible02: false, // 详情对话框

            // 表单数据绑定
            addDepartment: {},      // 新增部门表单
            updateDepartment: {},   // 修改部门表单
            updateDepartment02: {}  // 详情页表单
        };
    }
};
</script>

<!-- CSS样式表部分 -->
<style scoped>
/* 设置表格行背景色 */
.el-table .cc {
    background-color: #FAFFFF;
}

.el-button--text {
    margin-right: 15px;
}

.el-select {
    width: 300px;
}

.el-input {
    width: 200px;
}

/* 对话框按钮间距 */
.dialog-footer button:first-child {
    margin-right: 10px;
}

/* 分页组件位置调整 */
.el-pagination {
    margin-left: 230px;
}

/* 表格宽度 */
.el-table {
    width: 1020px;
}
</style>
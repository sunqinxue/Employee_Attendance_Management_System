<!-- 
  @Description: 加班记录前端页面
  @author： 孙勤学
  @date：2025/9/17
-->
<template>    
	<!--第一行查询输入框和按钮 开始-->
	<el-row>
		<el-col :span="6">
	        <el-input
	            placeholder="请输入加班记录ID或员工ID"  size="small"
	            v-model="employee_id" style="width: 200px;">
	        </el-input>
	    </el-col>
	    <el-col :span="3">
	        <el-button @click="searchClick()" size="small">查询加班记录</el-button>
	    </el-col>
	    <el-col :span="3">
	        <el-button @click="openInsertDialog()" size="small">新增加班记录</el-button><br/>
	    </el-col>
		<el-col :span="3">
		    <el-button @click="datdel()" :disabled="this.selItems.length==0" size="small">
				批量删除</el-button><br/>
		</el-col>
	</el-row>
	<!-- 第一行查询输入框和按钮 结束-->
	
	<!-- 第二行数据表格 开始   opacity:0.5; width: 80%  style="width:68%;background-color: transparent;"-->
	<el-table :data="overtime_recordsData" 
	@selection-change="handleSelectionChange"  :cell-class-name="cellClassFn">
		<!--表格第1列 复选框-->   <!-- overtime_id, employee_id, start_time, end_time, duration, multiplier, status, created_time -->
		<el-table-column
		  type="selection"
		  width="55" align="left" style="background-color: #333;">
		</el-table-column>    
		<el-table-column fixed prop="overtime_id" label="加班记录ID" width="120" style="background-color: #333;"/>
	    <el-table-column prop="employee_id" label="员工ID" width="120" />
		<el-table-column prop="start_time" label="加班开始时间" width="120" />
		<el-table-column prop="end_time" label="加班结束时间" width="120" />
		<el-table-column prop="duration" label="加班时长（小时）" width="120" />
		<el-table-column prop="multiplier" label="薪资倍数" width="120" />
		<el-table-column prop="status" label="审批状态" width="120" />
		<el-table-column prop="created_time" label="申请时间" width="120" />
		<el-table-column fixed="right" label="编辑" width="280">
			<template #default="scope">
				<!-- <el-icon><Sugar /></el-icon> -->
				<div style="background-color: transparent">
					<el-button type="info" size="small" @click="openUpdateDialog(scope.$index, scope.row)">					   		<el-icon><Edit /></el-icon>
					</el-button>
					<el-button type="danger" size="small" @click="deleteRow(scope.$index,scope.row)">
						<el-icon><Delete /></el-icon>
					</el-button>
					<el-button type="primary" circle size="small"  @click="openUpdateDialog02(scope.$index, scope.row)">
						<el-icon><View /></el-icon>
					</el-button>
				</div>
			</template>
		</el-table-column>	
	</el-table>
	<!-- 第二行数据表格 结束-->
	<!-- totalRow totalCount v-show="this.overtime_recordsData.length>0" -->
	<!--第三行分页组件 开始-->
	<el-col :span="5">
	    <el-pagination
		    small
	        background
	        :page-size="pageSize" :current-page.sync="currentPage"
	        layout="prev, pager, next" 
			:total="totalCount" @current-change="currentChange" v-show="this.totalCount>0" >
	    </el-pagination>
	</el-col>
	<!--第三行分页组件 结束-->
	
	<!--新增加班记录对话框 开始-->
	<el-dialog v-model="insertVisible" title="新增加班记录">
		<el-form>
			<el-row>
				<el-col :span="11" >
					<el-form-item label="加班记录ID" >
						<el-input v-model="addOvertime_records.overtime_id" autocomplete="off" 
						type="number" size="small" />
					</el-form-item>
				</el-col>	
				<el-col :span="11">
					<el-form-item label="员工ID" >
						<el-select placeholder="员工ID" size="small"
							v-model="addOvertime_records.employee_id"
							clearable filterable style="width:200px">
								<el-option 
									v-for="item in overtimeRecordsArr"
									:key="item.overtime_id"
									:label="item.employee_id"
									:value="item.employee_id">
								</el-option>  
						</el-select>
					</el-form-item>
				</el-col>
			</el-row>
			<el-row>
				<el-col :span="11" >
					<el-form-item label="加班开始时间" >
						<el-input v-model="addOvertime_records.start_time" autocomplete="off" size="small"/>
					</el-form-item>
				</el-col>	
				<el-col :span="11">
					<el-form-item label="加班结束时间" >
						<el-input v-model="addOvertime_records.end_time" autocomplete="off" size="small"/>
					</el-form-item>
				</el-col>
			</el-row>
			<el-row>
				<el-col :span="11" >
					<el-form-item label="加班时长（小时）" >
						<el-input v-model="addOvertime_records.duration" autocomplete="off" 
						type="number" size="small"/>
					</el-form-item>
				</el-col>	
				<el-col :span="11">
					<el-form-item label="薪资倍数" >
						<el-input v-model="addOvertime_records.multiplier" autocomplete="off"
						type="number" size="small"/>
					</el-form-item>
				</el-col>
			</el-row>
			<el-row>
				<el-col :span="11">
					<el-form-item label="审批状态" >
						<el-input v-model="addOvertime_records.status" autocomplete="off" size="small"/>
					</el-form-item>
				</el-col>
				<el-col :span="11">
					<el-form-item label="申请时间" >
						<el-input v-model="addOvertime_records.created_time" autocomplete="off" size="small"/>
					</el-form-item>
				</el-col>
			</el-row>
		</el-form>
		<template #footer>
		    <span class="dialog-footer">
		        <el-button type="primary" @click="addNewOvertime_records()" size="small">保存</el-button>
				<el-button @click="insertVisible = false" size="small">取消</el-button>
		    </span>
		</template>
	</el-dialog>
	<!--新增加班记录对话框 结束-->
		 
	<!--修改加班记录对话框 开始-->
	<el-dialog v-model="updateVisible" title="修改加班记录">
		<el-form>
			<el-row>
				<el-col :span="11" >
					<el-form-item label="加班记录ID" >
						<el-input v-model="updateOvertime_records.overtime_id" autocomplete="off" 
						type="number" size="small" readonly/>
					</el-form-item>
				</el-col>	
				<el-col :span="11">
					<el-form-item label="员工ID" >
						<el-select placeholder="员工ID" size="small"
							v-model="updateOvertime_records.employee_id"
							clearable filterable style="width:200px">
								<el-option 
									v-for="item in overtimeRecordsArr"
									:key="item.overtime_id"
									:label="item.employee_id"
									:value="item.employee_id">
								</el-option>  
						</el-select>
					</el-form-item>
				</el-col>
			</el-row>
			<el-row>
				<el-col :span="11" >
					<el-form-item label="加班开始时间" >
						<el-input v-model="updateOvertime_records.start_time" autocomplete="off" size="small"/>
					</el-form-item>
				</el-col>	
				<el-col :span="11">
					<el-form-item label="加班结束时间" >
						<el-input v-model="updateOvertime_records.end_time" autocomplete="off" size="small"/>
					</el-form-item>
				</el-col>
			</el-row>
			<el-row>
				<el-col :span="11" >
					<el-form-item label="加班时长（小时）" >
						<el-input v-model="updateOvertime_records.duration" autocomplete="off" 
						type="number" size="small"/>
					</el-form-item>
				</el-col>	
				<el-col :span="11">
					<el-form-item label="薪资倍数" >
						<el-input v-model="updateOvertime_records.multiplier" autocomplete="off" size="small"/>
					</el-form-item>
				</el-col>
			</el-row>
			<el-row>	
				<el-col :span="11">
					<el-form-item label="审批状态" >
						<el-input v-model="updateOvertime_records.status" autocomplete="off" size="small"/>
					</el-form-item>
				</el-col>
				<el-col :span="11">
					<el-form-item label="申请时间" >
						<el-input v-model="updateOvertime_records.created_time" autocomplete="off" size="small"/>
					</el-form-item>
				</el-col>
			</el-row>
		</el-form>
		<template #footer>
			<span class="dialog-footer">
				<el-button type="primary" @click="modifyOvertime_records()" size="small">保存</el-button>
				<el-button @click="updateVisible = false" size="small">取消</el-button>
			</span>
		</template>
	</el-dialog>
	<!--更新加班记录对话框 结束-->
	
	<!--查看加班记录详情对话框 开始-->
	<el-dialog v-model="updateVisible02" title="查看加班记录详情">
		<el-form>
			<el-row>
				<el-col :span="11" >
					<el-form-item label="加班记录ID" >
						<el-input v-model="updateOvertime_records02.overtime_id" autocomplete="off" 
						type="number" size="small" readonly/>
					</el-form-item>
				</el-col>	
				<el-col :span="11">
					<el-form-item label="员工ID" >
						<el-input v-model="updateOvertime_records02.employee_id" autocomplete="off"  size="small" readonly/>
					</el-form-item>
				</el-col>
			</el-row>
			<el-row>
				<el-col :span="11" >
					<el-form-item label="加班开始时间" >
						<el-input v-model="updateOvertime_records02.start_time" autocomplete="off" size="small" readonly/>
					</el-form-item>
				</el-col>	
				<el-col :span="11">
					<el-form-item label="加班结束时间" >
						<el-input v-model="updateOvertime_records02.end_time" autocomplete="off" size="small" readonly/>
					</el-form-item>
				</el-col>
			</el-row>
			<el-row>
				<el-col :span="11" >
					<el-form-item label="加班时长（小时）" >
						<el-input v-model="updateOvertime_records02.duration" autocomplete="off" 
						type="number" size="small" readonly/>
					</el-form-item>
				</el-col>	
				<el-col :span="11">
					<el-form-item label="薪资倍数" >
						<el-input v-model="updateOvertime_records02.multiplier" autocomplete="off" size="small" readonly/>
					</el-form-item>
				</el-col>
			</el-row>
			<el-row>	
				<el-col :span="11">
					<el-form-item label="审批状态" >
						<el-input v-model="updateOvertime_records02.status" autocomplete="off" size="small" readonly/>
					</el-form-item>
				</el-col>
				<el-col :span="11">
					<el-form-item label="申请时间" >
						<el-input v-model="updateOvertime_records02.created_time" autocomplete="off" size="small" readonly/>
					</el-form-item>
				</el-col>
			</el-row>
		</el-form>
		<template #footer>
			<span class="dialog-footer">
				<el-button type="primary" @click="updateVisible02 = false" size="small">取消</el-button>
			</span>
		</template>
	</el-dialog>
	<!--查看加班记录详情对话框 结束-->
</template>

<!--javaScript代码部分-->
<script>
	import qs from 'qs';        //处理字符串的工具类
	import axios from 'axios';  //异步访问后端的工具类
	import { ElMessage } from 'element-plus'; //element信息框工具类
	
	export default {
		//vue的方法区
		methods:{
			    //设置表格背景色
			    cellClassFn({row,column,rowIndex,columnIndex}){
				   return 'cc';
			    },
	            //查询按钮执行的方法
				searchClick(){
				    this.currentPage=1;
				    this.getData(this.currentPage, this.pageSize);
				},
				//查询方法==获取后端加班记录数据 
				getData(page, count){
					//在不同的方法里,this有可能代表不同的对象,希望_this代表最初的对象
					let _this=this;
					let url = "http://localhost:7070/newOvertime_records/listOvertime_records?pageNum=" + page 
					+ "&maxPageNum=" + count + "&keywords=" + _this.employee_id;
					//获取加班记录数据 后端设置跨域访问了，前端不用设置了
					axios.get(url).then(resp=> {  //箭头函数
						_this.overtime_recordsData = resp.data.list;
						_this.totalCount = resp.data.totalRow;
						console.log(_this.overtime_recordsData);
					});
				},
				//刷新方法
				refresh() {
					//在不同的方法里,this有可能代表不同的对象,希望_this代表最初的对象
				    let _this = this;
				    _this.getData(this.currentPage, this.pageSize);
				},
				//翻页方法
				currentChange(currPage){
				    this.currentPage = currPage;
				    this.getData(currPage, this.pageSize);
				},
				//激活批量删除按钮
				handleSelectionChange(val) {
				    this.selItems = val;
				},
				//打开新增对话框
				openInsertDialog() {
					//在不同的方法里,this有可能代表不同的对象,希望_this代表最初的对象
					let _this = this;
					_this.insertVisible = true;
					// 获取加班记录列表数据用于下拉选择
					let url = "http://localhost:7070/newOvertime_records/listOvertime_records?pageNum=1&maxPageNum=100&keywords=";
					axios.get(url).then(resp=> {
						_this.overtimeRecordsArr = resp.data.list;
					});
				},
				//添加加班记录的方法
				addNewOvertime_records(){
					//代码片段里this有可能代表不同的对象,希望_this代表最初的对象
					var _this = this;
				    if ( _this.addOvertime_records.overtime_id == null || _this.addOvertime_records.overtime_id.length == 0
					||_this.addOvertime_records.employee_id == null || _this.addOvertime_records.employee_id.length == 0 ) {
				        ElMessage({
					       message: '数据不能为空!',
					       type: 'info',
					  	   duration: 1000, //停留1秒钟
					  	   //showClose: true //可手动关闭
					    })
				    }
				    else {
					    let str=qs.stringify(_this.addOvertime_records);//处理字符串的工具类  
						//overtime_id=91&employee_id=XX&start_time=2023-01-01
						let url = "http://localhost:7070/newOvertime_records/addOvertime_records?"+str;
						//axios.post(url,str).then(resp=> {
						axios.get(url).then(resp=> {
						if (resp.status == 200) {
							var json = resp.data;
							//alert("json="+json);
							if(json=='1') {
								ElMessage({
								    message: '添加成功',
								    type: 'success', //类型
									duration: 1000,  //停留1秒钟
								})
							} else {
								ElMessage({
								    message: '添加失败',
								    type: 'error',  //类型
									duration: 3000, //停留3秒钟
									showClose: true //可手动关闭
								})
							}
							_this.addOvertime_records.overtime_id = '';
							_this.addOvertime_records.employee_id = '';
							_this.addOvertime_records.start_time = '';
							_this.addOvertime_records.end_time = '';
							_this.addOvertime_records.duration = '';
							_this.addOvertime_records.multiplier = '';
							_this.addOvertime_records.status = '';
							_this.addOvertime_records.created_time = '';
							_this.refresh();
				        }
				    }, resp=> {
				        if (resp.response.status == 403) {
							ElMessage({
								 message: '资源不可用',
								 type: 'error',
								 duration: 3000, //停留3秒钟
								 showClose: true //可手动关闭
							})
						}
				    });
				  }
				},
				//打开修改对话框
				openUpdateDialog(rIndex, row){
					var _this = this;
					_this.updateVisible = true;
					
					// 获取加班记录列表数据用于下拉选择
					let url = "http://localhost:7070/newOvertime_records/listOvertime_records?pageNum=1&maxPageNum=100&keywords=";
					axios.get(url).then(resp=> {
						_this.overtimeRecordsArr = resp.data.list;
					});
					
				    _this.updateOvertime_records.overtime_id=row.overtime_id;
					_this.updateOvertime_records.employee_id=row.employee_id;
					_this.updateOvertime_records.start_time=row.start_time;
					_this.updateOvertime_records.end_time=row.end_time;
					_this.updateOvertime_records.duration=row.duration;
					_this.updateOvertime_records.multiplier=row.multiplier;
					_this.updateOvertime_records.status=row.status;
					_this.updateOvertime_records.created_time=row.created_time;
				},
				
				//打开查看详情对话框
				openUpdateDialog02(rIndex, row){
					var _this = this;
					_this.updateVisible02 = true
				    _this.updateOvertime_records02.overtime_id=row.overtime_id;
					_this.updateOvertime_records02.employee_id=row.employee_id;
					_this.updateOvertime_records02.start_time=row.start_time;
					_this.updateOvertime_records02.end_time=row.end_time;
					_this.updateOvertime_records02.duration=row.duration;
					_this.updateOvertime_records02.multiplier=row.multiplier;
					_this.updateOvertime_records02.status=row.status;
					_this.updateOvertime_records02.created_time=row.created_time;
				},
				
				//修改加班记录的方法
				modifyOvertime_records() {
				    //在不同的方法里,this有可能代表不同的对象,希望_this代表最初的对象
				    let _this = this;
				    if (_this.updateOvertime_records.overtime_id == null || 
					       _this.updateOvertime_records.overtime_id.length == 0
				       || _this.updateOvertime_records.employee_id == null || 
					      _this.updateOvertime_records.employee_id.length == 0) {
						ElMessage({
						   message: '数据不能为空!',
						   type: 'info',
						   duration: 3000, //停留3秒钟
						   showClose: true //可手动关闭
						})
				    }
				  else {
				   let str=qs.stringify(_this.updateOvertime_records);
				   let url = "http://localhost:7070/newOvertime_records/updateOvertime_records";
				   axios.post(url, str).then(resp=> {   
						var json = resp.data;
				        //alert("json="+json);
						if(json=='1') {
							ElMessage({
							    message: '修改成功',
							    type: 'success', //类型
								duration: 1000,  //停留1秒钟
							})
							 _this.refresh();
						} else {
							ElMessage({
							    message: '修改失败',
							    type: 'error',  //类型
								duration: 3000, //停留3秒钟
								showClose: true //可手动关闭
							})
						}
				    }, resp=> {
				        if (resp.response.status == 403) {
				            ElMessage({
						      message: '资源不可用',
						      type: 'error',
						  	  duration: 3000, //停留3秒钟
						  	  showClose: true //可手动关闭
						  })
				        }
				    });
					_this.updateOvertime_records.overtime_id = '';
					_this.updateOvertime_records.employee_id = '';
					_this.updateOvertime_records.start_time = '';
					_this.updateOvertime_records.end_time = '';
					_this.updateOvertime_records.duration = '';
					_this.updateOvertime_records.multiplier = '';
					_this.updateOvertime_records.status = '';
					_this.updateOvertime_records.created_time = '';
				    _this.updateVisible = false;
					_this.drawer = false;
				   
				   }
				},
				//删除按钮执行的方法
				deleteRow(rIndex,row) {
					let _this = this;
					_this.$confirm('确认删除 "' + row.employee_id + '" ?', '提示', {
					  confirmButtonText: '确定',
					  cancelButtonText: '取消',
					  type: 'warning'
					}).then(() => {
					  _this.deleteOvertime_records(row.overtime_id);
					  //删除数组中的数据
					  _this.overtime_recordsData.splice(rIndex,1);
					}).catch(() => {
					   //取消
					});
				},
				//删除加班记录==调用后端
				deleteOvertime_records(ids) {
				    let _this = this;
				    let str = "overtime_id=" + ids;
					let url = "http://localhost:7070/newOvertime_records/deleteOvertime_records";
					axios.post(url,str).then(resp=> {
					let json = resp.data;
					if(json=='1') {
						ElMessage({
						    message: '删除成功',
						    type: 'success', //停留1秒钟
							duration: 1000,
						})
					} else {
						ElMessage({
						    message: '删除失败',
						    type: 'error',
							duration: 3000, //停留3秒钟
							showClose: true //可手动关闭
						})
					}
				    _this.refresh();
				  }, resp=> {
				    _this.loading = false;
				    if (resp.response.status == 403) {
				      ElMessage({
				          message: '资源不可用',
				          type: 'error',
				      	duration: 3000, //停留3秒钟
				      	showClose: true //可手动关闭
				      })
				    } else if (resp.response.status == 500) {
				      ElMessage({
				          message: '服务器端代码错误',
				          type: 'error',
				      	  duration: 3000, //停留3秒钟
				      	  showClose: true //可手动关闭
				      })
				    }
				  })
				},
				datdel() { //批量删除加班记录
					//alert("datdel()");
					let _this = this;
					_this.$confirm('确认删除这 ' + _this.selItems.length + ' 条数据?'
					, '提示', {
					  type: 'warning',
					  confirmButtonText: '确定',
					  cancelButtonText: '取消'
					}).then(()=> {
					  let selItems = _this.selItems;
					  let ids = '';
					  for (let i = 0; i < selItems.length; i++) {
					    ids += selItems[i].overtime_id + ","; //3,6,10    ,
					  }
					  //alert("ids="+ids);
					  _this.deleteOvertime_records(ids.substring(0, ids.length - 1));
					  _this.refresh();
					}).catch(() => {
					  //取消
					});
				},
		},
		//vue的数据区
		data() {
				return {
					//翻页相关 {
					currentPage: 1,
					pageSize: 5,
					totalCount: '',
					//翻页相关 }
					selItems: [], //复选框-批量删除用
					employee_id:'',
					overtime_recordsData:[],  //接收服务器传来的加班记录数据
					insertVisible: false, //用于新增对话框的显示和隐藏
					updateVisible: false, //用于更新对话框的显示和隐藏
					updateVisible02: false, //用于查看详情对话框的显示和隐藏
					addOvertime_records:{},
					updateOvertime_records:{},
					updateOvertime_records02:{},//用于查看详情
					overtimeRecordsArr:[]  // 用于存储加班记录数据，供下拉选择使用
				}
		},
    }
</script>

<!--css样式表部分-->
<style scoped>
	/* 设置表格背景色 */
	.el-table .cc {
		/* #CFFAF8 #42B983 #FAFFFF  transparent */
		background-color: #FAFFFF;
	}
	.el-button--text {
	  margin-right: 15px;
	}
	.el-select {
	  width: 300px;
	}
	.el-input {
	  width: 200px;
	}
	.dialog-footer button:first-child {
	  margin-right: 10px;
	}
	.el-pagination{
		margin-left: 230px;
	}
	.el-table {
		width: 1260px;
	}
</style>
import { createRouter, createWebHistory } from 'vue-router';
import axios from 'axios';
const routes = [
  {
	path:'/',
	redirect: '/login'
  },
  {
    path: '/login',
    name: 'login',
    component: () => import('../views/Login.vue')
  },
  {
    path: '/home',
    name: 'home',
  	component: () => import('../views/Home.vue'),
  	 children:[
			{
			 	path:'/user',
			 	name:'user',
			 	component:()=>import('../components/sysmag/User.vue')
			},
			{
				path:'/Shifts',
				name:'Shifts',
				component:()=>import('../components/sysmag/Shifts.vue')  
			},
			{
				path:'/Clock_records',
				name:'Clock_records',
				component:()=>import('../components/sysmag/Clock_records.vue')  
			},
			{
				path:'/Leave_types',
				name:'Leave_types',
				component:()=>import('../components/sysmag/Leave_types.vue')  
			},
			{
				path:'/Leave_records',
				name:'Leave_records',
				component:()=>import('../components/sysmag/Leave_records.vue')  
			},
			{
				path:'/Overtime_records',
				name:'Overtime_records',
				component:()=>import('../components/sysmag/Overtime_records.vue')  
			},
			{
				path:'/System_logs',
				name:'System_logs',
				component:()=>import('../components/sysmag/System_logs.vue')  
			},
			{
				path:'/Departments',
				name:'Departments',
				component:()=>import('../components/sysmag/Departments.vue')  
			},
		]
    }
]

const router = createRouter({
  //gjadd
  base: '/myapp',
  mode: 'history',
  //gjadd
  history: createWebHistory(process.env.BASE_URL),
  routes
})

export default router

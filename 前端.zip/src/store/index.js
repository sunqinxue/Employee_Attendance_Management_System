/*
import { createStore } from 'vuex'

export default createStore({
  state: {
	 num:0,
	 user:{userName:qq}
  },
  getters: {
	  
  },
  mutations: {
	num(state,r){
		state.num=r
	},
	user(state,u){
		state.user=u
	}
  },
  actions: {
	  
  },
  modules: {
  }
})
*/



import { createStore } from 'vuex'

export default createStore({
  state: {
	 
  },
  getters: {
  },
  mutations: {
  },
  actions: {
  },
  modules: {
  }
})

